import { useNavigate, useParams } from 'react-router-dom';
import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query';
import { deleteLaw, getLawById, updateLaw } from '../services/api';
import {
  ChevronRight,
  Edit3,
  Trash2,
  Clock,
  CheckCircle2,
  ArrowRight,
  AlertCircle,
  FileText,
  AlertTriangle,
  History,
  Calendar,
  ShieldCheck,
  ShieldAlert,
  CircleDollarSign,
  Settings,
  Briefcase,
} from 'lucide-react';
import StatusBadge from '../components/StatusBadge';

const IMPACT_ICON_MAP = {
  Operational: Settings,
  Compliance: ShieldAlert,
  Financial: CircleDollarSign,
  Safety: Briefcase,
};

export default function LawDetailPage() {
  const { id } = useParams();
  const navigate = useNavigate();
  const queryClient = useQueryClient();

  const { data: law, isLoading, isError } = useQuery({
    queryKey: ['law', id],
    queryFn: () => getLawById(id),
    retry: 1,
  });

  const updateMutation = useMutation({
    mutationFn: (data) => updateLaw(id, data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['law', id] });
      queryClient.invalidateQueries({ queryKey: ['laws'] });
    },
  });

  const deleteMutation = useMutation({
    mutationFn: () => deleteLaw(id),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['laws'] });
      queryClient.invalidateQueries({ queryKey: ['notifications', 'status'] });
      navigate('/laws');
    },
  });

  if (isLoading) return <LoadingDetail />;

  if (isError || !law) {
    return (
      <div className="p-20 text-center space-y-4">
        <div className="w-20 h-20 bg-red-500/10 rounded-full flex items-center justify-center text-red-500 mx-auto">
          <AlertTriangle size={40} />
        </div>
        <h2 className="text-2xl font-black text-white">Texte introuvable</h2>
        <p className="text-slate-500 max-w-xs mx-auto">Le texte reglementaire que vous recherchez a peut-etre ete supprime.</p>
        <button onClick={() => navigate('/laws')} className="text-[#2DD4BF] font-black uppercase text-xs tracking-widest hover:underline pt-4 transition-all">
          Retour au Repertoire
        </button>
      </div>
    );
  }

  const handleDelete = () => {
    if (confirm('Supprimer definitivement ce texte reglementaire ? Cette action est irreversible.')) {
      deleteMutation.mutate();
    }
  };

  const dateStr = law.publishedAt
    ? new Date(law.publishedAt).toLocaleDateString('fr-FR', { year: 'numeric', month: 'long', day: 'numeric' })
    : 'Non renseignee';

  const confidencePct = Math.round((Number(law.confidence) || 0) * 100);

  return (
    <div className="space-y-10 animate-fade-in pb-24">
      <div className="flex items-center gap-3 text-[10px] font-black uppercase text-slate-500 tracking-widest">
        <span className="hover:text-white cursor-pointer transition-colors" onClick={() => navigate('/laws')}>
          Repertoire
        </span>
        <ChevronRight size={14} className="text-slate-700" />
        <span className="text-white truncate max-w-xs">{law.title}</span>
      </div>

      <div className="flex flex-col md:flex-row md:items-start justify-between gap-10">
        <div className="space-y-4 max-w-4xl">
          <div className="flex items-center gap-4 flex-wrap">
            <StatusBadge status={law.status} />
            <span className="text-[10px] font-black text-slate-500 uppercase tracking-[0.2em]">
              {law.category}
              {law.subCategory ? ` / ${law.subCategory}` : ''}
            </span>
          </div>
          <h1 className="text-4xl font-black text-white tracking-tight leading-[1.1]">{law.title}</h1>
        </div>

        <div className="flex items-center gap-4 shrink-0">
          <button
            onClick={() => navigate(`/laws/${id}/edit`)}
            className="flex items-center gap-3 bg-white/5 hover:bg-white/10 text-white px-7 py-4 rounded-2xl text-sm font-black border border-white/5 transition-all active:scale-95 shadow-xl group"
          >
            <Edit3 size={18} className="text-[#2DD4BF] group-hover:scale-110 transition-transform" />
            <span>Modifier</span>
          </button>
          <button
            disabled={deleteMutation.isPending}
            onClick={handleDelete}
            className="flex items-center justify-center p-4 rounded-2xl bg-red-500/10 hover:bg-red-500/20 text-red-500 border border-red-500/10 transition-all active:scale-95 shadow-xl disabled:opacity-30"
            title="Supprimer ce texte"
          >
            <Trash2 size={22} />
          </button>
        </div>
      </div>

      <div className="grid grid-cols-2 md:grid-cols-4 gap-6 p-10 rounded-[32px] bg-[#0B1121] border border-white/5 shadow-2xl">
        <InfoItem label="Type de Texte" value={law.type} />
        <InfoItem label="Theme Principal" value={law.category} />
        <InfoItem label="Sous-theme" value={law.subCategory || '-'} />
        <InfoItem label="Date de Publication" value={dateStr} icon={<Calendar size={14} className="text-slate-600" />} />
      </div>

      <div className="grid grid-cols-1 xl:grid-cols-3 gap-10">
        <div className="xl:col-span-2 space-y-8">
          <section className="p-8 rounded-3xl bg-white/5 border border-white/5 shadow-xl space-y-7">
            <div className="flex items-center justify-between gap-4 flex-wrap">
              <div>
                <p className="text-[10px] font-black uppercase tracking-widest text-slate-500">Analyse de Pertinence</p>
                <h3 className="text-xl font-black text-white mt-1">Pertinence Marsa Maroc / SMA Port d'Agadir</h3>
              </div>
              <span
                className={`px-4 py-2 rounded-xl text-[11px] font-black uppercase tracking-wider border ${
                  law.priority === 'HIGH'
                    ? 'bg-red-500/15 text-red-400 border-red-500/30'
                    : law.priority === 'MEDIUM'
                      ? 'bg-amber-500/15 text-amber-300 border-amber-500/30'
                      : 'bg-slate-500/15 text-slate-300 border-slate-500/30'
                }`}
              >
                Priorite: {law.priority || 'LOW'}
              </span>
            </div>

            <div className="p-6 rounded-2xl bg-[#0B1121] border border-white/5">
              <p className="text-[10px] font-black uppercase tracking-widest text-slate-500 mb-3">Reasoning</p>
              <p className="text-slate-300 text-sm leading-relaxed">
                {law.reason || 'Aucune justification enregistree pour cette loi.'}
              </p>
            </div>

            <div className="grid md:grid-cols-2 gap-6">
              <div className="p-6 rounded-2xl bg-[#0B1121] border border-white/5 space-y-3">
                <p className="text-[10px] font-black uppercase tracking-widest text-slate-500">Impact</p>
                <div className="flex flex-wrap gap-2">
                  {(law.impact || 'Compliance')
                    .split(',')
                    .map((entry) => entry.trim())
                    .filter(Boolean)
                    .map((entry) => {
                      const Icon = IMPACT_ICON_MAP[entry] || ShieldAlert;
                      return (
                        <span key={entry} className="inline-flex items-center gap-2 px-3 py-1.5 rounded-xl bg-[#2DD4BF]/10 text-[#2DD4BF] text-[11px] font-black uppercase tracking-widest border border-[#2DD4BF]/10">
                          <Icon size={12} />
                          {entry}
                        </span>
                      );
                    })}
                </div>
              </div>

              <div className="p-6 rounded-2xl bg-[#0B1121] border border-white/5 space-y-3">
                <p className="text-[10px] font-black uppercase tracking-widest text-slate-500">Confidence</p>
                <div className="flex items-end gap-3">
                  <span className="text-4xl font-black text-white tracking-tight">{confidencePct}%</span>
                  <span className="text-xs font-black uppercase text-slate-500 pb-1">AI confidence</span>
                </div>
                <div className="w-full bg-white/5 h-2 rounded-full overflow-hidden border border-white/10">
                  <div className="bg-[#2DD4BF] h-full rounded-full transition-all duration-700" style={{ width: `${confidencePct}%` }} />
                </div>
              </div>
            </div>
          </section>

          <div className="p-10 md:p-14 rounded-[48px] bg-[#0B1121] border border-white/5 shadow-2xl space-y-10 relative overflow-hidden">
            <div className="absolute top-0 right-0 p-10 opacity-5 pointer-events-none">
              <ShieldCheck size={200} />
            </div>

            <div className="flex items-center gap-4">
              <div className="w-12 h-12 bg-[#2DD4BF]/10 rounded-2xl flex items-center justify-center text-[#2DD4BF]">
                <FileText size={24} />
              </div>
              <div>
                <p className="text-[10px] font-black text-slate-500 uppercase tracking-widest">Contenu du Texte</p>
                <p className="text-sm font-black text-white">{law.type}</p>
              </div>
            </div>

            {law.content ? (
              <div className="text-slate-300 font-medium leading-relaxed text-lg whitespace-pre-wrap">{law.content}</div>
            ) : (
              <div className="text-slate-600 italic text-base text-center py-10 border border-dashed border-white/5 rounded-3xl">
                Aucun contenu detaille enregistre pour ce texte.
                <br />
                <button onClick={() => navigate(`/laws/${id}/edit`)} className="text-[#2DD4BF] text-sm font-black mt-3 block hover:underline mx-auto">
                  + Ajouter du contenu
                </button>
              </div>
            )}
          </div>
        </div>

        <div className="space-y-8">
          <div className="p-10 rounded-[40px] bg-[#010410]/40 border border-white/5 space-y-10 shadow-2xl backdrop-blur-md">
            <div className="flex items-center gap-4 border-b border-white/10 pb-6">
              <div className="w-10 h-10 bg-white/5 rounded-xl flex items-center justify-center text-[#2DD4BF]">
                <History size={20} />
              </div>
              <h3 className="text-sm font-black text-white uppercase tracking-widest">Suivi du Statut</h3>
            </div>
            <div className="space-y-10 ml-2 relative before:absolute before:left-[11px] before:top-2 before:bottom-2 before:w-[2px] before:bg-white/5">
              <StatusStep done label="Enregistre" date="Texte ajoute au registre" />
              <StatusStep done={law.status !== 'NOT_APPLIED'} label="En cours de traitement" date={law.status !== 'NOT_APPLIED' ? 'Revision engagee' : 'En attente'} />
              <StatusStep active={law.status === 'APPLIED'} label="Conformite Active" date={law.status === 'APPLIED' ? 'Actuellement applique' : 'Activation en attente'} />
            </div>
          </div>

          <div className="p-10 rounded-[40px] bg-[#0B1121] border border-white/5 shadow-2xl space-y-8">
            <div>
              <span className="text-[10px] font-black text-slate-500 uppercase tracking-widest">Controles de Gestion</span>
              <h4 className="text-sm font-bold text-white mt-1">Cycle de Vie</h4>
            </div>

            <div className="space-y-4">
              <StatusButton
                active={law.status === 'APPLIED'}
                onClick={() => updateMutation.mutate({ status: 'APPLIED' })}
                variant="emerald"
                label="Marquer comme Applique"
                icon={<CheckCircle2 size={20} />}
                loading={updateMutation.isPending && updateMutation.variables?.status === 'APPLIED'}
              />
              <StatusButton
                active={law.status === 'IN_PROGRESS'}
                onClick={() => updateMutation.mutate({ status: 'IN_PROGRESS' })}
                variant="amber"
                label="Mettre En Cours"
                icon={<Clock size={20} />}
                loading={updateMutation.isPending && updateMutation.variables?.status === 'IN_PROGRESS'}
              />
              <StatusButton
                active={law.status === 'NOT_APPLIED'}
                onClick={() => updateMutation.mutate({ status: 'NOT_APPLIED' })}
                variant="red"
                label="Non Applique"
                icon={<AlertCircle size={20} />}
                loading={updateMutation.isPending && updateMutation.variables?.status === 'NOT_APPLIED'}
              />
            </div>

            <div className="pt-6 border-t border-white/5 flex items-center gap-3 opacity-40">
              <Clock size={14} className="text-slate-500" />
              <span className="text-[10px] font-black uppercase text-slate-500 tracking-widest">Mis a jour par MarsaTrack</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

function InfoItem({ label, value, icon }) {
  return (
    <div className="space-y-2 group">
      <p className="text-[10px] font-black uppercase text-slate-500 tracking-[0.2em] leading-none group-hover:text-[#2DD4BF] transition-colors">
        {label}
      </p>
      <div className="flex items-center gap-2">
        {icon}
        <p className="text-base font-black text-white tracking-tight">{value}</p>
      </div>
    </div>
  );
}

function StatusStep({ label, date, active, done }) {
  return (
    <div className={`relative pl-12 flex flex-col justify-center ${!active && !done ? 'opacity-25' : ''}`}>
      <div
        className={`absolute left-0 top-1/2 -translate-y-1/2 w-6 h-6 rounded-full border-[5px] border-[#010410] z-10 ${
          done ? 'bg-[#2DD4BF]' : active ? 'bg-[#2DD4BF] ring-8 ring-[#2DD4BF]/10' : 'bg-slate-700'
        }`}
      />
      <h5 className={`text-sm font-black tracking-tight ${active || done ? 'text-white' : 'text-slate-500'}`}>{label}</h5>
      <p className="text-[10px] text-slate-500 mt-1 font-bold">{date}</p>
    </div>
  );
}

function StatusButton({ active, onClick, variant, label, icon, loading }) {
  const idle = {
    emerald: 'bg-[#10B981]/10 text-[#10B981] border-[#10B981]/10 hover:bg-[#10B981]/20',
    amber: 'bg-amber-500/10 text-amber-500 border-amber-500/10 hover:bg-amber-500/20',
    red: 'bg-red-500/10 text-red-500 border-red-500/10 hover:bg-red-500/20',
  };

  const enabled = {
    emerald: 'bg-[#10B981] text-[#010410] border-[#10B981]',
    amber: 'bg-amber-500 text-[#010410] border-amber-500',
    red: 'bg-red-500 text-white border-red-500',
  };

  return (
    <button
      onClick={onClick}
      disabled={loading}
      className={`w-full p-4 rounded-2xl flex items-center justify-between group transition-all duration-200 border ${
        active ? enabled[variant] : idle[variant]
      } ${loading ? 'opacity-50 scale-95 cursor-wait' : 'hover:-translate-y-0.5 active:scale-95 shadow-lg shadow-black/20'}`}
    >
      <div className="flex items-center gap-4">
        <div className="group-hover:scale-110 transition-transform">{icon}</div>
        <span className="text-[12px] font-black uppercase tracking-widest">{loading ? 'Mise a jour...' : label}</span>
      </div>
      {!loading && <ArrowRight size={16} className="group-hover:translate-x-1 transition-transform" />}
    </button>
  );
}

function LoadingDetail() {
  return (
    <div className="space-y-10 animate-pulse pb-20">
      <div className="w-32 h-3 bg-white/5 rounded" />
      <div className="space-y-4">
        <div className="w-24 h-6 bg-white/5 rounded-full" />
        <div className="w-2/3 h-14 bg-white/5 rounded-2xl" />
      </div>
      <div className="grid grid-cols-4 gap-6 p-10 bg-white/5 rounded-3xl h-28" />
      <div className="grid xl:grid-cols-3 gap-10">
        <div className="xl:col-span-2 h-[500px] bg-white/5 rounded-[48px]" />
        <div className="space-y-8">
          <div className="h-64 bg-white/5 rounded-[40px]" />
          <div className="h-72 bg-white/5 rounded-[40px]" />
        </div>
      </div>
    </div>
  );
}
