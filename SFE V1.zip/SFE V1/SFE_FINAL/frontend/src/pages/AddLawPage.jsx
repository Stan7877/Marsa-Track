import { useEffect, useState } from 'react';
import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query';
import { createLaw, updateLaw, getLawById } from '../services/api';
import { useNavigate, useParams } from 'react-router-dom';
import {
  ChevronRight,
  Save,
  Layout,
  Layers,
  Bold,
  Italic,
  List,
} from 'lucide-react';

const CATEGORIES = [
  'Environnement',
  'Eau',
  'Air',
  'Sante & Securite au Travail',
  'Energie',
  'Qualite',
  'Maritime',
  'Securite',
  'Autres exigences',
];

const TYPES = ['Loi', 'Decret', 'Arrete', 'Dahir', 'Circulaire', 'Reglement', 'Norme', 'Autre'];

const EMPTY_FORM = {
  title: '',
  type: 'Loi',
  publishedAt: '',
  category: 'Maritime',
  subCategory: '',
  content: '',
  status: 'NOT_APPLIED',
  isApplicable: true,
  reason: '',
  impact: '',
  priority: 'LOW',
  confidence: '',
};

export default function AddLawPage() {
  const navigate = useNavigate();
  const queryClient = useQueryClient();
  const { id } = useParams();
  const isEdit = Boolean(id && !id.includes('new'));

  const [formData, setFormData] = useState(EMPTY_FORM);
  const [error, setError] = useState(null);

  const { data: existing } = useQuery({
    queryKey: ['law', id],
    queryFn: () => getLawById(id),
    enabled: isEdit,
  });

  useEffect(() => {
    if (!existing) return;

    setFormData({
      title: existing.title || '',
      type: existing.type || 'Loi',
      publishedAt: existing.publishedAt ? existing.publishedAt.slice(0, 10) : '',
      category: existing.category || 'Maritime',
      subCategory: existing.subCategory || '',
      content: existing.content || '',
      status: existing.status || 'NOT_APPLIED',
      isApplicable: existing.isApplicable !== false,
      reason: existing.reason || '',
      impact: existing.impact || '',
      priority: existing.priority || 'LOW',
      confidence: existing.confidence ?? '',
    });
  }, [existing]);

  const set = (field, value) => setFormData((prev) => ({ ...prev, [field]: value }));

  const mutation = useMutation({
    mutationFn: (data) => (isEdit ? updateLaw(id, data) : createLaw(data)),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['laws'] });
      queryClient.invalidateQueries({ queryKey: ['notifications', 'status'] });
      if (isEdit) queryClient.invalidateQueries({ queryKey: ['law', id] });
      navigate('/laws');
    },
    onError: (err) => {
      setError(err?.response?.data?.error || 'Une erreur est survenue.');
    },
  });

  const handleSubmit = (event) => {
    event.preventDefault();
    setError(null);

    if (!formData.title.trim()) {
      setError('Le titre est obligatoire.');
      return;
    }

    if (!formData.category.trim()) {
      setError('La categorie est obligatoire.');
      return;
    }

    const confidenceValue =
      formData.confidence === '' || formData.confidence === null || formData.confidence === undefined
        ? null
        : Number(formData.confidence);

    mutation.mutate({
      ...formData,
      confidence: Number.isFinite(confidenceValue) ? confidenceValue : null,
      publishedAt: formData.publishedAt ? new Date(formData.publishedAt).toISOString() : null,
    });
  };

  return (
    <div className="space-y-8 animate-fade-in pb-32">
      <div className="flex items-center gap-3 text-[10px] font-black uppercase text-slate-500 tracking-widest">
        <span className="hover:text-white cursor-pointer transition-colors" onClick={() => navigate('/laws')}>
          Repertoire
        </span>
        <ChevronRight size={14} className="text-slate-700" />
        <span className="text-white">{isEdit ? 'Modifier le Texte' : 'Nouveau Texte'}</span>
      </div>

      <div className="space-y-2">
        <h1 className="text-4xl font-extrabold text-white tracking-tight">
          {isEdit ? 'Modifier le Texte Reglementaire' : 'Ajouter un Nouveau Texte'}
        </h1>
        <p className="text-slate-400 text-lg font-medium leading-relaxed">
          Documenter la legislation et les exigences de conformite pour le port d'Agadir.
        </p>
      </div>

      {error && <div className="p-4 rounded-2xl bg-red-500/10 border border-red-500/20 text-red-400 text-sm font-bold">{error}</div>}

      <form onSubmit={handleSubmit} className="grid grid-cols-1 xl:grid-cols-3 gap-10">
        <div className="xl:col-span-2 space-y-8">
          <div className="p-8 rounded-3xl bg-[#0B1121] border border-white/5 space-y-8 shadow-2xl">
            <div className="space-y-2">
              <label className="text-[11px] font-black text-slate-500 uppercase tracking-widest pl-1">
                Titre du Texte <span className="text-red-500">*</span>
              </label>
              <input
                type="text"
                value={formData.title}
                onChange={(event) => set('title', event.target.value)}
                placeholder="Titre officiel complet de la loi ou du decret"
                className="w-full bg-white/5 border border-white/5 rounded-2xl py-4 px-6 text-base text-white placeholder-white/20 focus:outline-none focus:ring-1 focus:ring-[#2DD4BF] focus:bg-white/10 transition-all font-bold"
                required
              />
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div className="space-y-2">
                <label className="text-[11px] font-black text-slate-500 uppercase tracking-widest pl-1">Type de Texte</label>
                <select
                  value={formData.type}
                  onChange={(event) => set('type', event.target.value)}
                  className="w-full bg-white/5 border border-white/5 rounded-2xl py-4 px-6 text-base text-white focus:outline-none focus:ring-1 focus:ring-[#2DD4BF] focus:bg-white/10 appearance-none font-bold"
                >
                  {TYPES.map((type) => (
                    <option key={type} value={type} className="bg-[#0B1121]">
                      {type}
                    </option>
                  ))}
                </select>
              </div>
              <div className="space-y-2">
                <label className="text-[11px] font-black text-slate-500 uppercase tracking-widest pl-1">Date de Publication</label>
                <input
                  type="date"
                  value={formData.publishedAt}
                  onChange={(event) => set('publishedAt', event.target.value)}
                  className="w-full bg-white/5 border border-white/5 rounded-2xl py-4 px-6 text-base text-white focus:outline-none focus:ring-1 focus:ring-[#2DD4BF] focus:bg-white/10 transition-all font-bold"
                />
              </div>
            </div>

            <div className="space-y-2">
              <label className="text-[11px] font-black text-slate-500 uppercase tracking-widest pl-1">Contenu & Dispositions</label>
              <div className="bg-white/5 border border-white/5 rounded-3xl overflow-hidden focus-within:ring-1 focus-within:ring-[#2DD4BF] transition-all min-h-[280px] flex flex-col">
                <div className="bg-white/5 border-b border-white/5 p-4 flex items-center gap-4 text-slate-600">
                  <Bold size={16} />
                  <Italic size={16} />
                  <List size={16} />
                </div>
                <textarea
                  rows={10}
                  value={formData.content}
                  onChange={(event) => set('content', event.target.value)}
                  placeholder="Redigez ou collez le texte legal ici..."
                  className="flex-1 bg-transparent py-6 px-8 text-white placeholder-white/20 resize-none outline-none font-medium leading-relaxed"
                />
              </div>
            </div>
          </div>
        </div>

        <div className="space-y-8">
          <div className="p-8 rounded-3xl bg-[#0B1121] border border-white/5 space-y-8 shadow-2xl">
            <h3 className="text-sm font-black text-white uppercase tracking-widest border-b border-white/5 pb-4">Classification</h3>

            <div className="space-y-2">
              <label className="text-[10px] font-black text-slate-500 uppercase tracking-[0.2em] block">
                Theme Principal <span className="text-red-500">*</span>
              </label>
              <div className="relative group">
                <select
                  value={formData.category}
                  onChange={(event) => set('category', event.target.value)}
                  className="w-full bg-white/5 border border-white/5 rounded-2xl py-4 px-6 text-sm text-white font-bold appearance-none group-hover:bg-white/10 focus:outline-none focus:ring-1 focus:ring-[#2DD4BF] transition-all"
                >
                  {CATEGORIES.map((category) => (
                    <option key={category} value={category} className="bg-[#0B1121]">
                      {category}
                    </option>
                  ))}
                </select>
                <Layout className="absolute right-5 top-1/2 -translate-y-1/2 text-slate-500 pointer-events-none" size={16} />
              </div>
            </div>

            <div className="space-y-2">
              <label className="text-[10px] font-black text-slate-500 uppercase tracking-[0.2em] block">Sous-categorie</label>
              <div className="relative group">
                <input
                  type="text"
                  value={formData.subCategory}
                  onChange={(event) => set('subCategory', event.target.value)}
                  placeholder="ex: Gestion des Dechets"
                  className="w-full bg-white/5 border border-white/5 rounded-2xl py-4 px-6 text-sm text-white font-bold group-hover:bg-white/10 focus:outline-none focus:ring-1 focus:ring-[#2DD4BF] transition-all"
                />
                <Layers className="absolute right-5 top-1/2 -translate-y-1/2 text-slate-500 pointer-events-none" size={16} />
              </div>
            </div>

            <div className="space-y-2">
              <label className="text-[10px] font-black text-slate-500 uppercase tracking-[0.2em] block">Statut Initial</label>
              <select
                value={formData.status}
                onChange={(event) => set('status', event.target.value)}
                className="w-full bg-white/5 border border-white/5 rounded-2xl py-4 px-6 text-sm text-white font-bold appearance-none focus:outline-none focus:ring-1 focus:ring-[#2DD4BF] transition-all"
              >
                <option value="NOT_APPLIED" className="bg-[#0B1121]">Non applique</option>
                <option value="IN_PROGRESS" className="bg-[#0B1121]">En cours</option>
                <option value="APPLIED" className="bg-[#0B1121]">Applique</option>
              </select>
            </div>

            <div className="space-y-2">
              <label className="text-[10px] font-black text-slate-500 uppercase tracking-[0.2em] block">Applicabilite</label>
              <select
                value={formData.isApplicable ? 'true' : 'false'}
                onChange={(event) => set('isApplicable', event.target.value === 'true')}
                className="w-full bg-white/5 border border-white/5 rounded-2xl py-4 px-6 text-sm text-white font-bold appearance-none focus:outline-none focus:ring-1 focus:ring-[#2DD4BF] transition-all"
              >
                <option value="true" className="bg-[#0B1121]">Applicable</option>
                <option value="false" className="bg-[#0B1121]">Non applicable</option>
              </select>
            </div>

            <h3 className="text-sm font-black text-white uppercase tracking-widest border-b border-white/5 pb-4 pt-6">Analyse de Pertinence (Override)</h3>

            <div className="space-y-2">
              <label className="text-[10px] font-black text-slate-500 uppercase tracking-[0.2em] block">Priorite Marsa Maroc</label>
              <select
                value={formData.priority}
                onChange={(event) => set('priority', event.target.value)}
                className="w-full bg-white/5 border border-white/5 rounded-2xl py-4 px-6 text-sm text-white font-bold appearance-none focus:outline-none focus:ring-1 focus:ring-[#2DD4BF] transition-all"
              >
                <option value="LOW" className="bg-[#0B1121]">LOW (Faible)</option>
                <option value="MEDIUM" className="bg-[#0B1121]">MEDIUM (Moyenne)</option>
                <option value="HIGH" className="bg-[#0B1121]">HIGH (Haute)</option>
              </select>
            </div>

            <div className="space-y-2">
              <label className="text-[10px] font-black text-slate-500 uppercase tracking-[0.2em] block">Type d'Impact</label>
              <input
                type="text"
                value={formData.impact}
                onChange={(event) => set('impact', event.target.value)}
                placeholder="ex: Operational, Compliance"
                className="w-full bg-white/5 border border-white/5 rounded-2xl py-4 px-6 text-sm text-white font-bold focus:outline-none focus:ring-1 focus:ring-[#2DD4BF] transition-all"
              />
            </div>

            <div className="space-y-2">
              <label className="text-[10px] font-black text-slate-500 uppercase tracking-[0.2em] block">Confidence IA (0-1)</label>
              <input
                type="number"
                min="0"
                max="1"
                step="0.01"
                value={formData.confidence}
                onChange={(event) => set('confidence', event.target.value)}
                placeholder="ex: 0.82"
                className="w-full bg-white/5 border border-white/5 rounded-2xl py-4 px-6 text-sm text-white font-bold focus:outline-none focus:ring-1 focus:ring-[#2DD4BF] transition-all"
              />
            </div>

            <div className="space-y-2">
              <label className="text-[10px] font-black text-slate-500 uppercase tracking-[0.2em] block">Justification (Pourquoi ?)</label>
              <textarea
                rows={4}
                value={formData.reason}
                onChange={(event) => set('reason', event.target.value)}
                placeholder="Expliquez pourquoi ce texte est pertinent..."
                className="w-full bg-white/5 border border-white/5 rounded-2xl py-4 px-6 text-sm text-white font-medium focus:outline-none focus:ring-1 focus:ring-[#2DD4BF] transition-all resize-none"
              />
            </div>
          </div>
        </div>

        <div className="fixed bottom-0 left-64 right-0 flex justify-end gap-6 z-40 bg-[#010410]/90 backdrop-blur-md px-10 py-5 border-t border-white/10 shadow-2xl">
          <button
            type="button"
            onClick={() => navigate('/laws')}
            className="px-8 py-4 text-sm font-black uppercase text-slate-400 hover:text-white transition-colors"
          >
            Annuler
          </button>
          <button
            type="submit"
            disabled={mutation.isPending}
            className="px-12 py-4 bg-[#2DD4BF] hover:bg-[#2DD4BF]/90 text-[#010410] font-black rounded-2xl flex items-center gap-3 transition-all active:scale-95 shadow-xl shadow-[#2DD4BF]/10 disabled:opacity-50"
          >
            <Save size={20} strokeWidth={2.5} />
            <span>{mutation.isPending ? 'Enregistrement...' : isEdit ? 'Sauvegarder les modifications' : 'Enregistrer le Texte'}</span>
          </button>
        </div>
      </form>
    </div>
  );
}
