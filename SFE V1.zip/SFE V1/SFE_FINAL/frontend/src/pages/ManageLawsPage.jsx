import { useEffect, useMemo, useRef, useState } from 'react';
import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query';
import {
  getLaws,
  getCategories,
  getTypes,
  importPdfLaws,
  deleteLaw,
  getNotificationStatus,
} from '../services/api';
import {
  Search,
  Download,
  MoreVertical,
  ChevronLeft,
  ChevronRight,
  FileText,
  Clock3,
  ShieldCheck,
  Plus,
  Upload,
  CheckCircle2,
  AlertTriangle,
  X,
  Loader2,
  Edit3,
  Trash2,
  FileSearch,
} from 'lucide-react';
import { useNavigate } from 'react-router-dom';

const PRIORITY_STYLES = {
  HIGH: 'border-red-500/30 bg-red-500/10 text-red-300',
  MEDIUM: 'border-amber-500/30 bg-amber-500/10 text-amber-300',
  LOW: 'border-slate-600 bg-slate-700/20 text-slate-300',
};

const STATUS_META = {
  APPLIED: {
    label: 'Applique',
    cls: 'border-teal-400/30 bg-teal-400/10 text-teal-300',
  },
  IN_PROGRESS: {
    label: 'En cours',
    cls: 'border-slate-600 bg-slate-700/20 text-slate-300',
  },
  NOT_APPLIED: {
    label: 'Non applique',
    cls: 'border-slate-600 bg-slate-700/20 text-slate-300',
  },
};

const IMPORT_PHASES = [
  'Televersement du PDF',
  'Extraction des textes',
  'Validation des correspondances',
  'Finalisation des resultats',
];

const ITEMS_PER_PAGE = 10;

export default function ManageLawsPage() {
  const navigate = useNavigate();
  const queryClient = useQueryClient();
  const fileInputRef = useRef(null);

  const [search, setSearch] = useState('');
  const [filters, setFilters] = useState({ category: '', type: '', status: '' });
  const [page, setPage] = useState(1);
  const [openMenuId, setOpenMenuId] = useState(null);

  const [importing, setImporting] = useState(false);
  const [importPhaseIndex, setImportPhaseIndex] = useState(0);
  const [importResult, setImportResult] = useState(null);
  const [importError, setImportError] = useState(null);

  const { data: laws = [], isLoading, isError } = useQuery({
    queryKey: ['laws', filters],
    queryFn: () => getLaws(filters),
    staleTime: 30000,
  });

  const { data: categories = [] } = useQuery({
    queryKey: ['categories'],
    queryFn: getCategories,
    staleTime: 300000,
  });

  const { data: types = [] } = useQuery({
    queryKey: ['types'],
    queryFn: getTypes,
    staleTime: 300000,
  });

  const { data: notificationStatus } = useQuery({
    queryKey: ['notifications', 'status'],
    queryFn: getNotificationStatus,
    refetchInterval: 30000,
    staleTime: 10000,
  });

  const deleteMutation = useMutation({
    mutationFn: deleteLaw,
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['laws'] });
      queryClient.invalidateQueries({ queryKey: ['notifications', 'status'] });
      setOpenMenuId(null);
    },
  });

  const filteredLaws = useMemo(() => {
    if (!search.trim()) return laws;

    const q = search.toLowerCase();
    return laws.filter((law) => {
      const title = String(law.title || '').toLowerCase();
      const content = String(law.content || '').toLowerCase();
      const category = String(law.category || '').toLowerCase();
      return title.includes(q) || content.includes(q) || category.includes(q);
    });
  }, [laws, search]);

  const totalPages = Math.max(1, Math.ceil(filteredLaws.length / ITEMS_PER_PAGE));
  const paginatedLaws = filteredLaws.slice((page - 1) * ITEMS_PER_PAGE, page * ITEMS_PER_PAGE);

  const appliedCount = laws.filter((law) => law.status === 'APPLIED').length;
  const inProgressCount = laws.filter((law) => law.status === 'IN_PROGRESS').length;
  const complianceRate = laws.length > 0 ? Math.round((appliedCount / laws.length) * 100) : 0;
  const newLawsCount = notificationStatus?.newLawsCount || 0;

  const stats = [
    { label: 'Total textes', value: laws.length, icon: FileText },
    { label: 'Appliques', value: appliedCount, icon: ShieldCheck },
    { label: 'En cours', value: inProgressCount, icon: Clock3 },
    { label: 'Taux de conformite', value: `${complianceRate}%`, icon: ShieldCheck },
  ];

  const uploadResults = importResult?.results || [];
  const pageNumbers = getVisiblePages(totalPages, page);

  useEffect(() => {
    setPage(1);
  }, [filters, search]);

  useEffect(() => {
    const handler = () => setOpenMenuId(null);
    document.addEventListener('click', handler);
    return () => document.removeEventListener('click', handler);
  }, []);

  useEffect(() => {
    if (!importing) {
      setImportPhaseIndex(0);
      return;
    }

    const interval = setInterval(() => {
      setImportPhaseIndex((current) => (current + 1) % IMPORT_PHASES.length);
    }, 900);

    return () => clearInterval(interval);
  }, [importing]);

  const handlePdfUpload = async (event) => {
    const file = event.target.files?.[0];
    if (!file) return;

    event.target.value = '';
    setImporting(true);
    setImportResult(null);
    setImportError(null);

    try {
      const result = await importPdfLaws(file);
      setImportResult(result);

      const applicableCount = result?.results?.length || result?.matched || result?.inserted || 0;
      if (applicableCount > 0) {
        queryClient.invalidateQueries({ queryKey: ['laws'] });
        queryClient.invalidateQueries({ queryKey: ['categories'] });
        queryClient.invalidateQueries({ queryKey: ['types'] });
        queryClient.invalidateQueries({ queryKey: ['notifications', 'status'] });
      }
    } catch (error) {
      setImportError(error?.response?.data?.error || "Erreur lors de l'importation du PDF.");
    } finally {
      setImporting(false);
    }
  };

  const handleExport = () => {
    const rows = [
      ['Titre', 'Type', 'Priorite', 'Impact', 'Categorie', 'Statut', 'Date de publication'],
      ...filteredLaws.map((law) => [
        `"${String(law.title || '').replace(/"/g, '""')}"`,
        law.type || '',
        law.priority || '',
        law.impact || '',
        law.category || '',
        law.status || '',
        law.publishedAt ? new Date(law.publishedAt).toLocaleDateString('fr-FR') : '',
      ]),
    ];

    const csv = rows.map((row) => row.join(',')).join('\n');
    const blob = new Blob(['\uFEFF' + csv], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const anchor = document.createElement('a');
    anchor.href = url;
    anchor.download = `lois-marsa-maroc-${new Date().toISOString().slice(0, 10)}.csv`;
    anchor.click();
    URL.revokeObjectURL(url);
  };

  const clearFilters = () => {
    setFilters({ category: '', type: '', status: '' });
    setSearch('');
  };

  const handleDelete = (event, id) => {
    event.stopPropagation();
    if (confirm('Supprimer definitivement ce texte reglementaire ?')) {
      deleteMutation.mutate(id);
    }
  };

  return (
    <div className="space-y-6 pb-6">
      <section className="rounded-xl border border-slate-800 bg-slate-950/80 p-6">
        <div className="flex flex-col gap-6 lg:flex-row lg:items-end lg:justify-between">
          <div className="space-y-2">
            <h1 className="text-3xl font-bold tracking-tight text-slate-100">Repertoire des textes</h1>
            <p className="max-w-2xl text-sm text-slate-400">
              Suivi de la conformite legale maritime pour Marsa Maroc - SMA Agadir.
            </p>
            {newLawsCount > 0 && (
              <span className="inline-flex items-center rounded-md border border-teal-400/30 bg-teal-400/10 px-2 py-1 text-xs font-medium text-teal-300">
                {newLawsCount} nouveau(x) texte(s) detecte(s)
              </span>
            )}
          </div>

          <div className="flex flex-wrap items-center gap-4">
            <input
              ref={fileInputRef}
              type="file"
              accept="application/pdf"
              className="hidden"
              onChange={handlePdfUpload}
            />

            <button
              onClick={() => fileInputRef.current?.click()}
              disabled={importing}
              className="inline-flex items-center gap-2 rounded-lg border border-slate-700 bg-slate-900 px-4 py-2 text-sm font-medium text-slate-200 transition-colors hover:border-teal-400/40 hover:text-teal-300 disabled:cursor-not-allowed disabled:opacity-60"
            >
              {importing ? <Loader2 size={16} className="animate-spin" /> : <Upload size={16} />}
              <span>{importing ? 'Import en cours' : 'Importer PDF'}</span>
            </button>

            <button
              onClick={() => navigate('/laws/new')}
              className="inline-flex items-center gap-2 rounded-lg border border-teal-400/40 bg-teal-400/10 px-4 py-2 text-sm font-medium text-teal-300 transition-colors hover:bg-teal-400/20"
            >
              <Plus size={16} />
              <span>Ajouter un texte</span>
            </button>
          </div>
        </div>

        {importing && (
          <div className="mt-6 rounded-lg border border-slate-800 bg-slate-900/60 p-4">
            <div className="flex items-center gap-2 text-sm font-medium text-slate-200">
              <Loader2 size={16} className="animate-spin text-teal-300" />
              <span>{IMPORT_PHASES[importPhaseIndex]}</span>
            </div>
            <div className="mt-3 h-1.5 w-full overflow-hidden rounded-full bg-slate-800">
              <div
                className="h-full rounded-full bg-teal-400 transition-all duration-300"
                style={{ width: `${((importPhaseIndex + 1) / IMPORT_PHASES.length) * 100}%` }}
              />
            </div>
            <p className="mt-2 text-xs text-slate-400">Traitement en cours, veuillez patienter...</p>
          </div>
        )}

        {(importResult || importError) && (
          <div
            className={`mt-6 flex items-start justify-between gap-4 rounded-lg border p-4 ${
              importError
                ? 'border-red-500/30 bg-red-500/10'
                : 'border-teal-400/30 bg-teal-400/10'
            }`}
          >
            <div className="flex items-start gap-3">
              <div className={importError ? 'text-red-300' : 'text-teal-300'}>
                {importError ? <AlertTriangle size={18} /> : <CheckCircle2 size={18} />}
              </div>
              <div className="space-y-1">
                <p className="text-sm font-semibold text-slate-100">
                  {importError ? "Echec de l'importation" : 'Importation terminee'}
                </p>
                <p className="text-sm text-slate-300">{importError || importResult?.message}</p>
              </div>
            </div>
            <button
              onClick={() => {
                setImportResult(null);
                setImportError(null);
              }}
              className="rounded-md p-1 text-slate-400 transition-colors hover:bg-slate-800 hover:text-slate-200"
              aria-label="Fermer"
            >
              <X size={16} />
            </button>
          </div>
        )}
      </section>

      <section className="grid grid-cols-1 gap-4 sm:grid-cols-2 xl:grid-cols-4">
        {stats.map((stat) => {
          const Icon = stat.icon;
          return (
            <article
              key={stat.label}
              className="rounded-xl border border-slate-800 bg-slate-950/80 p-6"
            >
              <div className="mb-4 inline-flex rounded-lg border border-slate-700 bg-slate-900 p-2 text-slate-300">
                <Icon size={16} />
              </div>
              <p className="text-xs font-medium uppercase tracking-wide text-slate-400">{stat.label}</p>
              <p className="mt-2 text-2xl font-semibold text-slate-100">{stat.value}</p>
            </article>
          );
        })}
      </section>

      {importResult && !importing && (
        <section className="rounded-xl border border-slate-800 bg-slate-950/80 p-6">
          <div className="flex flex-col gap-4 border-b border-slate-800 pb-4 sm:flex-row sm:items-end sm:justify-between">
            <div className="space-y-1">
              <h2 className="text-lg font-semibold text-slate-100">Resultats de l'import PDF</h2>
              <p className="text-sm text-slate-400">
                {uploadResults.length > 0
                  ? `${uploadResults.length} texte(s) applicable(s) trouve(s)`
                  : 'Aucun texte applicable détecté'}
              </p>
            </div>

            <div className="flex flex-wrap items-center gap-2 text-xs text-slate-300">
              <SummaryTag label="Extraits" value={importResult.detected || 0} />
              <SummaryTag label="Matches" value={importResult.matched || 0} />
              <SummaryTag label="Rejetes" value={importResult.rejected || 0} />
            </div>
          </div>

          {uploadResults.length === 0 ? (
            <div className="flex flex-col items-center justify-center gap-3 py-10 text-center">
              <div className="rounded-lg border border-slate-700 bg-slate-900 p-3 text-slate-400">
                <FileSearch size={20} />
              </div>
              <p className="text-sm text-slate-400">Aucun texte applicable détecté</p>
            </div>
          ) : (
            <div className="mt-4 max-h-[420px] space-y-3 overflow-y-auto pr-1">
              {uploadResults.map((law) => (
                <article
                  key={law.id || law.title}
                  className="rounded-lg border border-slate-800 bg-slate-900/60 p-4"
                >
                  <div className="flex items-start justify-between gap-4">
                    <h3 className="text-sm font-semibold leading-6 text-slate-100 md:text-base">{law.title}</h3>
                    <PriorityBadge priority={law.priority} />
                  </div>

                  <div className="mt-3 flex flex-wrap gap-2">
                    {parseImpactTokens(law.impact).map((token) => (
                      <span
                        key={`${law.id || law.title}-${token}`}
                        className="inline-flex items-center rounded-md border border-slate-700 bg-slate-900 px-2 py-1 text-xs text-slate-300"
                      >
                        {token}
                      </span>
                    ))}
                  </div>

                  <p className="mt-3 text-sm leading-6 text-slate-400">{law.reason || 'Raison non specifiee.'}</p>
                </article>
              ))}
            </div>
          )}
        </section>
      )}

      <section className="overflow-hidden rounded-xl border border-slate-800 bg-slate-950/80">
        <div className="border-b border-slate-800 p-6">
          <div className="grid gap-4 xl:grid-cols-[1fr_auto] xl:items-end">
            <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
              <FilterSelect
                label="Categorie"
                options={['Toutes Categories', ...categories]}
                value={filters.category}
                onChange={(value) => setFilters((prev) => ({ ...prev, category: value }))}
              />
              <FilterSelect
                label="Type"
                options={['Tous Types', ...types]}
                value={filters.type}
                onChange={(value) => setFilters((prev) => ({ ...prev, type: value }))}
              />
              <FilterSelect
                label="Statut"
                options={['Tout Statut', 'APPLIED', 'NOT_APPLIED', 'IN_PROGRESS']}
                optionLabels={{
                  APPLIED: 'Applique',
                  NOT_APPLIED: 'Non applique',
                  IN_PROGRESS: 'En cours',
                }}
                value={filters.status}
                onChange={(value) => setFilters((prev) => ({ ...prev, status: value }))}
              />
            </div>

            <div className="flex flex-col gap-4 sm:flex-row sm:items-center">
              <div className="relative min-w-[220px] flex-1">
                <Search className="pointer-events-none absolute left-3 top-1/2 -translate-y-1/2 text-slate-500" size={16} />
                <input
                  type="text"
                  placeholder="Rechercher un texte..."
                  value={search}
                  onChange={(event) => setSearch(event.target.value)}
                  className="w-full rounded-lg border border-slate-700 bg-slate-900 py-2 pl-10 pr-3 text-sm text-slate-100 placeholder-slate-500 outline-none transition-colors focus:border-teal-400/50"
                />
              </div>

              <button
                onClick={handleExport}
                className="inline-flex items-center justify-center gap-2 rounded-lg border border-slate-700 bg-slate-900 px-4 py-2 text-sm font-medium text-slate-200 transition-colors hover:border-teal-400/40 hover:text-teal-300"
              >
                <Download size={16} />
                <span>Exporter CSV</span>
              </button>
            </div>
          </div>
        </div>

        {isError && (
          <div className="flex flex-col items-center justify-center gap-3 p-10 text-center">
            <div className="rounded-lg border border-red-500/30 bg-red-500/10 p-3 text-red-300">
              <AlertTriangle size={20} />
            </div>
            <p className="text-sm font-medium text-slate-100">Impossible de charger les textes.</p>
            <p className="text-sm text-slate-400">Verifiez la connexion au backend puis reessayez.</p>
            <button
              onClick={() => queryClient.invalidateQueries({ queryKey: ['laws'] })}
              className="rounded-md border border-slate-700 bg-slate-900 px-3 py-1.5 text-xs font-medium text-slate-200 transition-colors hover:border-teal-400/40 hover:text-teal-300"
            >
              Reessayer
            </button>
          </div>
        )}

        {!isError && (
          <div className="overflow-x-auto">
            <table className="min-w-[1080px] w-full text-left">
              <thead>
                <tr className="border-b border-slate-800 text-xs uppercase tracking-wide text-slate-500">
                  <th className="px-6 py-4 font-medium">Titre</th>
                  <th className="px-6 py-4 font-medium">Type</th>
                  <th className="px-6 py-4 font-medium">Priorite</th>
                  <th className="px-6 py-4 font-medium">Impact</th>
                  <th className="px-6 py-4 font-medium">Categorie</th>
                  <th className="px-6 py-4 font-medium">Statut</th>
                  <th className="px-6 py-4 font-medium">Publication</th>
                  <th className="px-6 py-4 text-right font-medium">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-800">
                {isLoading ? (
                  Array.from({ length: 8 }).map((_, index) => <LoadingRow key={index} />)
                ) : filteredLaws.length === 0 ? (
                  <tr>
                    <td colSpan={8} className="px-6 py-12">
                      <div className="flex flex-col items-center justify-center gap-3 text-center">
                        <div className="rounded-lg border border-slate-700 bg-slate-900 p-3 text-slate-400">
                          <FileSearch size={20} />
                        </div>
                        <p className="text-sm font-medium text-slate-200">Aucun texte correspondant</p>
                        <p className="text-sm text-slate-400">Ajustez les filtres ou la recherche.</p>
                        <button
                          onClick={clearFilters}
                          className="rounded-md border border-slate-700 bg-slate-900 px-3 py-1.5 text-xs font-medium text-slate-200 transition-colors hover:border-teal-400/40 hover:text-teal-300"
                        >
                          Reinitialiser les filtres
                        </button>
                      </div>
                    </td>
                  </tr>
                ) : (
                  paginatedLaws.map((law) => (
                    <tr
                      key={law.id}
                      onClick={() => navigate(`/laws/${law.id}`)}
                      className="cursor-pointer transition-colors hover:bg-slate-900/60"
                    >
                      <td className="px-6 py-4">
                        <div className="flex min-w-[260px] items-start gap-3">
                          <div className="mt-1 rounded-md border border-slate-700 bg-slate-900 p-2 text-slate-400">
                            <FileText size={14} />
                          </div>
                          <div className="min-w-0 flex-1">
                            <p className="truncate text-sm font-medium text-slate-100">{law.title}</p>
                            <p className="mt-1 truncate text-xs text-slate-500">{law.subCategory || '-'}</p>
                          </div>
                        </div>
                      </td>
                      <td className="px-6 py-4">
                        <span className="inline-flex rounded-md border border-slate-700 bg-slate-900 px-2 py-1 text-xs text-slate-300">
                          {law.type || '-'}
                        </span>
                      </td>
                      <td className="px-6 py-4">
                        <PriorityBadge priority={law.priority} />
                      </td>
                      <td className="px-6 py-4">
                        <div className="flex max-w-[260px] flex-wrap gap-2">
                          {parseImpactTokens(law.impact).map((token) => (
                            <span
                              key={`${law.id}-${token}`}
                              className="inline-flex rounded-md border border-slate-700 bg-slate-900 px-2 py-1 text-xs text-slate-300"
                            >
                              {token}
                            </span>
                          ))}
                        </div>
                      </td>
                      <td className="px-6 py-4 text-sm text-slate-300">{law.category || '-'}</td>
                      <td className="px-6 py-4">
                        <StatusPill status={law.status} />
                      </td>
                      <td className="px-6 py-4 text-sm text-slate-400">
                        {law.publishedAt
                          ? new Date(law.publishedAt).toLocaleDateString('fr-FR', {
                              year: 'numeric',
                              month: 'short',
                              day: 'numeric',
                            })
                          : '-'}
                      </td>
                      <td className="px-6 py-4 text-right">
                        <div className="relative inline-block" onClick={(event) => event.stopPropagation()}>
                          <button
                            onClick={() => setOpenMenuId(openMenuId === law.id ? null : law.id)}
                            className="rounded-md p-2 text-slate-400 transition-colors hover:bg-slate-900 hover:text-slate-200"
                            aria-label="Actions"
                          >
                            <MoreVertical size={16} />
                          </button>

                          {openMenuId === law.id && (
                            <div className="absolute right-0 top-full z-20 mt-2 w-44 overflow-hidden rounded-lg border border-slate-700 bg-slate-900 shadow-lg shadow-black/30">
                              <button
                                onClick={() => {
                                  navigate(`/laws/${law.id}`);
                                  setOpenMenuId(null);
                                }}
                                className="flex w-full items-center gap-2 px-3 py-2 text-sm text-slate-200 transition-colors hover:bg-slate-800"
                              >
                                <FileText size={14} className="text-teal-300" />
                                <span>Voir details</span>
                              </button>
                              <button
                                onClick={() => {
                                  navigate(`/laws/${law.id}/edit`);
                                  setOpenMenuId(null);
                                }}
                                className="flex w-full items-center gap-2 px-3 py-2 text-sm text-slate-200 transition-colors hover:bg-slate-800"
                              >
                                <Edit3 size={14} className="text-slate-300" />
                                <span>Modifier</span>
                              </button>
                              <div className="h-px bg-slate-700" />
                              <button
                                onClick={(event) => handleDelete(event, law.id)}
                                className="flex w-full items-center gap-2 px-3 py-2 text-sm text-red-300 transition-colors hover:bg-red-500/10"
                              >
                                <Trash2 size={14} />
                                <span>Supprimer</span>
                              </button>
                            </div>
                          )}
                        </div>
                      </td>
                    </tr>
                  ))
                )}
              </tbody>
            </table>
          </div>
        )}

        {!isLoading && !isError && filteredLaws.length > 0 && (
          <div className="flex flex-col gap-4 border-t border-slate-800 p-6 text-sm text-slate-400 sm:flex-row sm:items-center sm:justify-between">
            <p>
              Affichage de{' '}
              <span className="font-medium text-slate-200">
                {Math.min((page - 1) * ITEMS_PER_PAGE + 1, filteredLaws.length)}
              </span>{' '}
              a{' '}
              <span className="font-medium text-slate-200">
                {Math.min(page * ITEMS_PER_PAGE, filteredLaws.length)}
              </span>{' '}
              sur <span className="font-medium text-slate-200">{filteredLaws.length}</span> textes
            </p>

            <div className="flex items-center gap-2">
              <button
                disabled={page === 1}
                onClick={() => setPage((prev) => prev - 1)}
                className="rounded-md border border-slate-700 bg-slate-900 p-2 text-slate-300 transition-colors hover:border-teal-400/40 hover:text-teal-300 disabled:cursor-not-allowed disabled:opacity-40"
              >
                <ChevronLeft size={16} />
              </button>

              {pageNumbers.map((pageNumber) => (
                <button
                  key={pageNumber}
                  onClick={() => setPage(pageNumber)}
                  className={`h-8 min-w-8 rounded-md border px-2 text-sm transition-colors ${
                    page === pageNumber
                      ? 'border-teal-400/40 bg-teal-400/10 text-teal-300'
                      : 'border-slate-700 bg-slate-900 text-slate-300 hover:border-teal-400/40 hover:text-teal-300'
                  }`}
                >
                  {pageNumber}
                </button>
              ))}

              <button
                disabled={page === totalPages}
                onClick={() => setPage((prev) => prev + 1)}
                className="rounded-md border border-slate-700 bg-slate-900 p-2 text-slate-300 transition-colors hover:border-teal-400/40 hover:text-teal-300 disabled:cursor-not-allowed disabled:opacity-40"
              >
                <ChevronRight size={16} />
              </button>
            </div>
          </div>
        )}
      </section>
    </div>
  );
}

function FilterSelect({ label, options, optionLabels = {}, value, onChange }) {
  return (
    <label className="space-y-2">
      <span className="block text-xs font-medium uppercase tracking-wide text-slate-500">{label}</span>
      <select
        value={value}
        onChange={(event) => onChange(event.target.value)}
        className="w-full rounded-lg border border-slate-700 bg-slate-900 px-3 py-2 text-sm text-slate-200 outline-none transition-colors focus:border-teal-400/50"
      >
        {options.map((option) => {
          const isAll = /^(Toutes|Tous|Tout)/i.test(option);
          return (
            <option key={option} value={isAll ? '' : option}>
              {optionLabels[option] || option}
            </option>
          );
        })}
      </select>
    </label>
  );
}

function PriorityBadge({ priority }) {
  const normalized = priority === 'HIGH' || priority === 'MEDIUM' || priority === 'LOW' ? priority : 'LOW';

  return (
    <span
      className={`inline-flex rounded-md border px-2 py-1 text-xs font-medium ${PRIORITY_STYLES[normalized]}`}
    >
      {normalized}
    </span>
  );
}

function StatusPill({ status }) {
  const config = STATUS_META[status] || {
    label: String(status || 'Inconnu').replace(/_/g, ' '),
    cls: 'border-slate-600 bg-slate-700/20 text-slate-300',
  };

  return (
    <span className={`inline-flex rounded-md border px-2 py-1 text-xs font-medium ${config.cls}`}>
      {config.label}
    </span>
  );
}

function SummaryTag({ label, value }) {
  return (
    <span className="inline-flex items-center rounded-md border border-slate-700 bg-slate-900 px-2 py-1 text-xs text-slate-300">
      {label}: {value}
    </span>
  );
}

function parseImpactTokens(impact) {
  const tokens = String(impact || 'Compliance')
    .split(',')
    .map((entry) => entry.trim())
    .filter(Boolean);

  return [...new Set(tokens)].slice(0, 4);
}

function getVisiblePages(totalPages, currentPage) {
  if (totalPages <= 7) {
    return Array.from({ length: totalPages }, (_, index) => index + 1);
  }

  const pages = new Set([1, totalPages, currentPage, currentPage - 1, currentPage + 1]);
  return [...pages]
    .filter((pageNumber) => pageNumber >= 1 && pageNumber <= totalPages)
    .sort((a, b) => a - b);
}

function LoadingRow() {
  return (
    <tr className="animate-pulse">
      <td className="px-6 py-4">
        <div className="h-4 w-72 rounded bg-slate-800" />
      </td>
      <td className="px-6 py-4">
        <div className="h-4 w-24 rounded bg-slate-800" />
      </td>
      <td className="px-6 py-4">
        <div className="h-4 w-16 rounded bg-slate-800" />
      </td>
      <td className="px-6 py-4">
        <div className="h-4 w-28 rounded bg-slate-800" />
      </td>
      <td className="px-6 py-4">
        <div className="h-4 w-20 rounded bg-slate-800" />
      </td>
      <td className="px-6 py-4">
        <div className="h-4 w-24 rounded bg-slate-800" />
      </td>
      <td className="px-6 py-4">
        <div className="h-4 w-20 rounded bg-slate-800" />
      </td>
      <td className="px-6 py-4">
        <div className="ml-auto h-8 w-8 rounded bg-slate-800" />
      </td>
    </tr>
  );
}