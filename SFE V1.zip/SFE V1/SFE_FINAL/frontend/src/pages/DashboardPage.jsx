import { useQuery } from '@tanstack/react-query';
import { getLaws } from '../services/api';
import {
  CheckCircle2,
  Clock,
  AlertTriangle,
  ArrowUpRight,
  ChevronRight,
  ShieldCheck,
  Layers,
  FileText,
  BarChart3,
  Calendar,
} from 'lucide-react';
import StatusBadge from '../components/StatusBadge';
import { useNavigate } from 'react-router-dom';

export default function DashboardPage() {
  const navigate = useNavigate();
  const { data: laws = [], isLoading, isError } = useQuery({
    queryKey: ['laws'],
    queryFn: getLaws,
    staleTime: 60000,
  });

  const appliedCount    = laws.filter((l) => l.status === 'APPLIED').length;
  const inProgressCount = laws.filter((l) => l.status === 'IN_PROGRESS').length;
  const notAppliedCount = laws.filter((l) => l.status === 'NOT_APPLIED').length;
  const complianceRate  = laws.length > 0 ? Math.round((appliedCount / laws.length) * 100) : 0;

  // Category breakdown
  const byCategory = laws.reduce((acc, l) => {
    acc[l.category] = (acc[l.category] || 0) + 1;
    return acc;
  }, {});
  const topCategories = Object.entries(byCategory)
    .sort((a, b) => b[1] - a[1])
    .slice(0, 5);

  if (isLoading) return <LoadingDashboard />;

  if (isError) return (
    <div className="p-20 text-center space-y-6 animate-fade-in text-white">
      <div className="w-20 h-20 bg-red-500/10 rounded-full flex items-center justify-center text-red-500 mx-auto border border-red-500/20">
        <AlertTriangle size={40} />
      </div>
      <h2 className="text-2xl font-black leading-none">Erreur de Connexion</h2>
      <p className="text-slate-500 max-w-sm mx-auto leading-relaxed">
        Impossible de récupérer les données. Vérifiez que le backend est démarré sur le port 3001.
      </p>
      <button
        onClick={() => window.location.reload()}
        className="text-[#2DD4BF] font-black uppercase text-xs tracking-widest hover:underline pt-4 transition-all"
      >
        Recharger la Page
      </button>
    </div>
  );

  return (
    <div className="space-y-10 animate-fade-in pb-10">
      <div className="space-y-3">
        <h1 className="text-5xl font-black text-white tracking-tight leading-none">Vue d'ensemble</h1>
        <p className="text-slate-400 max-w-2xl text-xl font-medium leading-relaxed opacity-90">
          Suivi en temps réel de la conformité réglementaire — Marsa Maroc, Port d'Agadir.
        </p>
      </div>

      {/* Stats cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <StatsCard icon={<Layers size={22} />}       title="Total des Textes"       value={laws.length}    label="REGISTRE" color="blue" />
        <StatsCard icon={<CheckCircle2 size={22} />} title="Entièrement Appliqués"  value={appliedCount}   label="ACTIF"    color="emerald" />
        <StatsCard icon={<Clock size={22} />}        title="En Cours de Révision"   value={inProgressCount} label="RÉVISION" color="amber" active />
        <StatsCard icon={<AlertTriangle size={22} />} title="Non-Conformes"         value={notAppliedCount} label="URGENT"  color="red" />
      </div>

      <div className="grid grid-cols-1 xl:grid-cols-3 gap-8 pt-4">
        {/* Recent laws */}
        <div className="xl:col-span-2 space-y-6">
          <div className="flex items-center justify-between px-2">
            <h3 className="text-2xl font-black text-white tracking-tight">Textes Récents</h3>
            <button
              onClick={() => navigate('/laws')}
              className="text-xs font-black text-[#2DD4BF] hover:text-white uppercase tracking-widest flex items-center gap-2 transition-all group"
            >
              Voir tout <ChevronRight size={14} className="group-hover:translate-x-1 transition-transform" />
            </button>
          </div>
          <div className="space-y-4">
            {laws.slice(0, 5).map((law) => (
              <LawUpdateItem key={law.id} law={law} onClick={() => navigate(`/laws/${law.id}`)} />
            ))}
          </div>
        </div>

        {/* Right panel */}
        <div className="space-y-8">
          {/* Compliance rate */}
          <div className="p-10 rounded-[48px] bg-gradient-to-br from-[#111827] to-[#0B1121] border border-white/5 shadow-2xl relative overflow-hidden group hover:border-[#2DD4BF]/20 transition-all">
            <div className="flex items-center justify-between mb-10">
              <span className="text-[10px] font-black text-slate-500 uppercase tracking-[0.3em]">Santé Globale</span>
              <div className="w-12 h-12 bg-[#2DD4BF]/10 rounded-2xl flex items-center justify-center text-[#2DD4BF]">
                <ShieldCheck size={24} />
              </div>
            </div>
            <div className="space-y-2">
              <div className="flex items-baseline gap-4 mb-4">
                <span className="text-7xl font-black text-white tracking-tighter">{complianceRate}%</span>
                <span className="text-xs font-black text-[#10B981] flex items-center gap-1 bg-[#10B981]/10 px-3 py-1 rounded-full">
                  <ArrowUpRight size={14} /> Taux d'application
                </span>
              </div>
              <div className="w-full bg-white/5 h-3.5 rounded-full overflow-hidden border border-white/5">
                <div
                  className="bg-gradient-to-r from-[#2DD4BF] to-[#10B981] h-full rounded-full transition-all duration-[1.5s]"
                  style={{ width: `${complianceRate}%` }}
                />
              </div>
            </div>
          </div>

          {/* Category breakdown */}
          <div className="p-8 rounded-[40px] bg-[#0B1121] border border-white/5 shadow-xl space-y-6">
            <div className="flex items-center gap-4">
              <div className="w-10 h-10 bg-blue-500/10 rounded-xl flex items-center justify-center text-blue-400">
                <BarChart3 size={20} />
              </div>
              <h4 className="text-sm font-black text-white">Répartition par Thème</h4>
            </div>
            <div className="space-y-3">
              {topCategories.map(([cat, count]) => {
                const pct = Math.round((count / laws.length) * 100);
                return (
                  <div key={cat}>
                    <div className="flex justify-between text-[11px] font-black mb-1">
                      <span className="text-slate-400 truncate max-w-[160px]">{cat}</span>
                      <span className="text-slate-500">{count}</span>
                    </div>
                    <div className="w-full bg-white/5 h-1.5 rounded-full overflow-hidden">
                      <div
                        className="bg-[#2DD4BF]/60 h-full rounded-full"
                        style={{ width: `${pct}%` }}
                      />
                    </div>
                  </div>
                );
              })}
            </div>
          </div>

          {/* Calendar placeholder */}
          <div className="p-8 rounded-[40px] bg-[#010410]/50 border border-white/5 shadow-2xl relative overflow-hidden">
            <div className="absolute top-0 right-0 p-8 opacity-5">
              <Calendar size={100} />
            </div>
            <span className="text-[10px] font-black text-slate-500 uppercase tracking-[0.3em] block mb-8">
              Échéance Agadir
            </span>
            <div className="space-y-8 relative before:absolute before:left-2 before:top-2 before:bottom-2 before:w-[2px] before:bg-white/5">
              <div className="relative pl-10 group">
                <div className="absolute left-0 top-1.5 w-4 h-4 bg-[#2DD4BF] rounded-full border-[4px] border-[#010410]" />
                <h5 className="text-sm font-black text-white leading-none mb-1">Audit de Sécurité</h5>
                <p className="text-[11px] text-slate-500 font-bold uppercase tracking-wider">
                  Phase 1 : Inspection du Terminal
                </p>
              </div>
              <div className="relative pl-10 opacity-30">
                <div className="absolute left-0 top-1.5 w-4 h-4 bg-slate-600 rounded-full border-[4px] border-[#010410]" />
                <h5 className="text-sm font-black text-slate-300 leading-none mb-1">Vérification Docs</h5>
                <p className="text-[11px] text-slate-500 font-bold tracking-wider">Prochainement</p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

function StatsCard({ icon, title, value, label, color, active }) {
  const configs = {
    blue:    'bg-blue-500/10 text-blue-400',
    emerald: 'bg-[#2DD4BF]/10 text-[#2DD4BF]',
    amber:   'bg-amber-500/10 text-amber-500',
    red:     'bg-red-500/10 text-red-500',
  };
  return (
    <div className={`p-8 rounded-[40px] bg-[#0B1121] border border-white/5 relative overflow-hidden flex flex-col justify-between h-48 ${active ? 'ring-2 ring-amber-500/20' : ''}`}>
      <div className="flex items-center justify-between">
        <div className={`p-3 rounded-2xl ${active ? 'bg-amber-500 text-[#010410]' : configs[color]}`}>
          {icon}
        </div>
        <span className="text-[9px] font-black text-slate-500 uppercase tracking-[0.3em]">{label}</span>
      </div>
      <div className="space-y-1">
        <span className="text-5xl font-black text-white tracking-tight">{value}</span>
        <p className="text-[11px] text-slate-500 font-black uppercase tracking-widest opacity-60">{title}</p>
      </div>
    </div>
  );
}

function LawUpdateItem({ law, onClick }) {
  const dateStr = law.publishedAt
    ? new Date(law.publishedAt).toLocaleDateString('fr-FR', { day: 'numeric', month: 'short', year: 'numeric' })
    : 'Récemment';
  return (
    <div
      onClick={onClick}
      className="p-5 rounded-3xl bg-[#0B1121] border border-white/5 flex items-center gap-5 hover:bg-white/5 transition-all cursor-pointer group hover:border-[#2DD4BF]/20 shadow-lg"
    >
      <div className="w-12 h-12 bg-white/5 rounded-2xl flex items-center justify-center text-[#2DD4BF] group-hover:scale-105 transition-transform shrink-0">
        <FileText size={22} />
      </div>
      <div className="flex-1 min-w-0">
        <h4 className="text-sm font-black text-white truncate group-hover:text-[#2DD4BF] transition-colors">
          {law.title}
        </h4>
        <p className="text-xs text-slate-500 font-bold uppercase tracking-widest opacity-70">
          {law.category}{law.subCategory ? ` · ${law.subCategory}` : ''}
        </p>
      </div>
      <div className="hidden md:flex flex-col items-end gap-2 shrink-0">
        <StatusBadge status={law.status} />
        <span className="text-[10px] text-slate-600 font-black uppercase tracking-[0.2em]">{dateStr}</span>
      </div>
      <ChevronRight size={18} className="text-slate-800 group-hover:text-white transition-all group-hover:translate-x-1 shrink-0" />
    </div>
  );
}

function LoadingDashboard() {
  return (
    <div className="space-y-10 animate-pulse p-4">
      <div className="w-64 h-10 bg-white/5 rounded-xl" />
      <div className="grid grid-cols-4 gap-6">
        {[1, 2, 3, 4].map((i) => <div key={i} className="h-48 bg-white/5 rounded-[40px]" />)}
      </div>
      <div className="grid xl:grid-cols-3 gap-8">
        <div className="xl:col-span-2 space-y-4">
          {[1, 2, 3, 4].map((i) => <div key={i} className="h-20 bg-white/5 rounded-3xl" />)}
        </div>
        <div className="space-y-8">
          <div className="h-48 bg-white/5 rounded-[48px]" />
          <div className="h-48 bg-white/5 rounded-[40px]" />
        </div>
      </div>
    </div>
  );
}
