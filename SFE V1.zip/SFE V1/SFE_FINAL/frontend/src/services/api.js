import axios from 'axios';

const api = axios.create({
  baseURL: import.meta.env.VITE_API_URL || 'http://localhost:3001/api',
});

export const getLaws = async (params = {}) => {
  const clean = Object.fromEntries(
    Object.entries(params).filter(([, value]) => value !== '' && value !== null && value !== undefined)
  );

  const { data } = await api.get('/laws', { params: clean });
  return data;
};

export const getLawById = async (id) => {
  const { data } = await api.get(`/laws/${id}`);
  return data;
};

export const createLaw = async (law) => {
  const { data } = await api.post('/laws', law);
  return data;
};

export const updateLaw = async (id, lawData) => {
  const { data } = await api.put(`/laws/${id}`, lawData);
  return data;
};

export const deleteLaw = async (id) => {
  await api.delete(`/laws/${id}`);
};

export const importPdfLaws = async (file) => {
  const formData = new FormData();
  formData.append('pdf', file);

  const { data } = await api.post('/laws/import-pdf', formData, {
    headers: { 'Content-Type': 'multipart/form-data' },
  });

  return data;
};

export const getCategories = async () => {
  const { data } = await api.get('/laws/meta/categories');
  return data;
};

export const getTypes = async () => {
  const { data } = await api.get('/laws/meta/types');
  return data;
};

export const runAutomation = async (force = false) => {
  const { data } = await api.post('/laws/automation/run', { force });
  return data;
};

export const getAutomationStatus = async () => {
  const { data } = await api.get('/laws/automation/status');
  return data;
};

export const getNotificationStatus = async () => {
  const { data } = await api.get('/laws/notifications/status');
  return data;
};

export const acknowledgeNotifications = async () => {
  const { data } = await api.post('/laws/notifications/ack');
  return data;
};
