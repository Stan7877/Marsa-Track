import Sidebar from './Sidebar';
import Header from './Header';
import { Outlet } from 'react-router-dom';

export default function Layout() {
  return (
    <div className="flex bg-[#010410] text-[#F9FAFB] min-h-screen font-sans selection:bg-[#2DD4BF]/30 selection:text-[#2DD4BF]">
      {/* Sidebar - Fixed on the left */}
      <Sidebar />
      
      {/* Main Content Area */}
      <div className="flex-1 lg:ml-64 flex flex-col min-h-screen">
        <Header />
        <main className="flex-1 px-10 py-10 bg-[#0B1121]/40 overflow-y-auto">
          <div className="max-w-[1600px] mx-auto">
            <Outlet />
          </div>
        </main>
        
        {/* Footer */}
        <footer className="h-14 px-10 flex items-center justify-between border-t border-white/5 bg-[#0B1121] text-[11px] text-slate-500 font-bold uppercase tracking-wider">
          <div className="flex items-center gap-2">
            <span className="w-2 h-2 rounded-full bg-[#2DD4BF]/50"></span>
            Marsa Maroc Group — Ports of Casablanca
          </div>
          <div className="flex items-center gap-4">
            <a href="#" className="hover:text-white transition-colors">© 2024 Legal Compliance Framework</a>
            <span className="text-white/10 px-2 line-clamp-1 opacity-20">|</span>
            <span className="hover:text-[#2DD4BF] transition-colors cursor-pointer">v2.4.0-Sentinel</span>
          </div>
        </footer>
      </div>
    </div>
  );
}
