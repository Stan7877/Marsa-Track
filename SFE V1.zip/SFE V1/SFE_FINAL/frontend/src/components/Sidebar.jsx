import { NavLink, useNavigate } from 'react-router-dom';
import {
  LayoutDashboard,
  Scale,
  Plus,
  Anchor,
  LifeBuoy,
} from 'lucide-react';

export default function Sidebar() {
  const navigate = useNavigate();

  const navItems = [
    { to: '/',     icon: LayoutDashboard, label: 'Tableau de bord' },
    { to: '/laws', icon: Scale,           label: 'Répertoire' },
  ];

  return (
    <aside className="hidden lg:flex w-64 bg-[#0B1121] h-screen fixed left-0 top-0 flex-col border-r border-white/5 z-40">
      {/* Logo */}
      <div className="p-8 pb-4">
        <div
          className="flex items-center gap-4 group cursor-pointer transition-all"
          onClick={() => navigate('/')}
        >
          <div className="w-11 h-11 bg-[#2DD4BF]/10 rounded-2xl flex items-center justify-center text-[#2DD4BF] border border-[#2DD4BF]/20 group-hover:bg-[#2DD4BF] group-hover:text-[#010410] transition-all duration-500 shadow-xl shadow-[#2DD4BF]/5">
            <Anchor size={26} strokeWidth={2.5} />
          </div>
          <div>
            <h1 className="text-xl font-black tracking-tight text-white leading-none">
              MarsaTrack <span className="text-[#2DD4BF]">Agadir</span>
            </h1>
            <span className="text-[10px] text-slate-500 font-black uppercase tracking-[0.2em] mt-1.5 block">
              Conformité Légale
            </span>
          </div>
        </div>
      </div>

      {/* Quick add button */}
      <div className="px-6 py-6">
        <NavLink
          to="/laws/new"
          className="flex items-center justify-center gap-3 w-full bg-[#2DD4BF] hover:bg-[#2DD4BF]/90 text-[#010410] font-black py-4 px-4 rounded-2xl transition-all shadow-xl shadow-[#2DD4BF]/10 group active:scale-95 leading-none"
        >
          <Plus size={18} strokeWidth={3} className="group-hover:rotate-90 transition-transform" />
          <span className="text-xs uppercase tracking-widest">Nouveau Texte</span>
        </NavLink>
      </div>

      {/* Navigation */}
      <nav className="flex-1 px-4 py-4 space-y-2 overflow-y-auto">
        {navItems.map((item) => (
          <NavLink
            key={item.to}
            to={item.to}
            end={item.to === '/'}
            className={({ isActive }) =>
              `flex items-center gap-4 px-4 py-4 rounded-2xl transition-all duration-200 text-[11px] font-black uppercase tracking-widest group border border-transparent ${
                isActive
                  ? 'bg-[#2DD4BF]/5 text-[#2DD4BF] border-white/5'
                  : 'text-slate-500 hover:text-slate-100 hover:bg-white/5'
              }`
            }
          >
            <item.icon size={20} strokeWidth={2.5} className="group-hover:scale-110 transition-transform" />
            <span>{item.label}</span>
          </NavLink>
        ))}
      </nav>

      {/* Bottom */}
      <div className="p-4 space-y-3">
        <div className="p-4 rounded-[28px] bg-white/5 border border-white/5 flex items-center gap-4 transition-all shadow-2xl">
          <div className="w-11 h-11 rounded-2xl bg-gradient-to-br from-slate-700 to-slate-900 border border-white/10 overflow-hidden shadow-inner flex items-center justify-center">
            <img src="https://api.dicebear.com/7.x/avataaars/svg?seed=Ahmad" alt="Profil" />
          </div>
          <div className="flex-1 min-w-0">
            <p className="text-xs font-black text-white truncate leading-none mb-1">Capitaine Ahmad</p>
            <p className="text-[9px] text-slate-500 font-black uppercase tracking-[0.2em]">Port d'Agadir</p>
          </div>
        </div>

        <div className="px-2">
          <button className="w-full flex items-center gap-4 px-4 py-3 text-slate-500 hover:text-white transition-colors text-[10px] font-black uppercase tracking-widest">
            <LifeBuoy size={18} strokeWidth={2.5} />
            <span>Centre d'aide</span>
          </button>
        </div>
      </div>
    </aside>
  );
}
