import { useEffect, useRef, useState } from 'react';
import {
  Search,
  Bell,
  HelpCircle,
  Menu,
  CheckCircle2,
} from 'lucide-react';
import { NavLink, useLocation } from 'react-router-dom';
import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query';
import { acknowledgeNotifications, getNotificationStatus } from '../services/api';

export default function Header() {
  const location = useLocation();
  const isDashboard = location.pathname === '/';
  const queryClient = useQueryClient();

  const { data: notifications } = useQuery({
    queryKey: ['notifications', 'status'],
    queryFn: getNotificationStatus,
    refetchInterval: 30000,
    staleTime: 10000,
  });

  const acknowledgeMutation = useMutation({
    mutationFn: acknowledgeNotifications,
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['notifications', 'status'] });
    },
  });

  const newLawsCount = notifications?.newLawsCount || 0;
  const previousCountRef = useRef(0);
  const initializedRef = useRef(false);
  const [toastCount, setToastCount] = useState(0);

  useEffect(() => {
    if (!initializedRef.current) {
      initializedRef.current = true;
      previousCountRef.current = newLawsCount;
      return;
    }

    const previousCount = previousCountRef.current;
    if (newLawsCount > previousCount) {
      setToastCount(newLawsCount);
    }
    previousCountRef.current = newLawsCount;
  }, [newLawsCount]);

  useEffect(() => {
    if (!toastCount) return undefined;

    const timer = setTimeout(() => {
      setToastCount(0);
    }, 5000);

    return () => clearTimeout(timer);
  }, [toastCount]);

  const handleNotificationsClick = () => {
    if (newLawsCount > 0) {
      acknowledgeMutation.mutate();
    }
  };

  return (
    <>
      {toastCount > 0 && (
        <div className="fixed top-6 right-6 z-[80] max-w-sm w-full rounded-2xl border border-[#2DD4BF]/20 bg-[#0d1f1a]/95 p-4 shadow-2xl">
          <div className="flex items-center gap-3 text-[#2DD4BF]">
            <CheckCircle2 size={18} />
            <p className="text-xs font-black uppercase tracking-wider">New laws detected</p>
          </div>
          <p className="text-sm text-white font-bold mt-2">
            {toastCount} nouvelle(s) loi(s) pertinente(s) detectee(s)
          </p>
        </div>
      )}

      <header className="h-24 flex items-center justify-between px-10 bg-[#0B1121] border-b border-white/5 sticky top-0 z-50 backdrop-blur-3xl bg-opacity-70">
        <div className="flex items-center gap-10 flex-1 max-w-4xl">
          <button className="md:hidden p-2 text-slate-400 hover:text-white hover:bg-white/5 rounded-xl transition-colors">
            <Menu size={24} />
          </button>

          <div className="relative group flex-1 max-w-xl">
            <div className="absolute inset-y-0 left-0 pl-4 flex items-center pointer-events-none">
              <Search size={18} className="text-slate-500 group-focus-within:text-[#2DD4BF] transition-colors" />
            </div>
            <input
              type="text"
              className="block w-full pl-11 pr-4 py-3.5 bg-white/5 border border-white/10 rounded-2xl focus:ring-1 focus:ring-[#2DD4BF] focus:border-[#2DD4BF]/30 focus:bg-[#0B1121] text-sm text-white placeholder-slate-500 transition-all outline-none"
              placeholder="Rechercher des textes, reglements, mots-cles..."
            />
          </div>

          {!isDashboard && (
            <nav className="hidden lg:flex items-center gap-8">
              <NavLink
                to="/"
                className={({ isActive }) =>
                  `text-[13px] font-black uppercase tracking-widest ${isActive ? 'text-[#2DD4BF]' : 'text-slate-500 hover:text-white'} transition-colors`
                }
              >
                Tableau de Bord
              </NavLink>
              <NavLink
                to="/laws"
                className={({ isActive }) =>
                  `text-[13px] font-black uppercase tracking-widest ${isActive ? 'text-[#2DD4BF] border-b-2 border-[#2DD4BF] pb-1' : 'text-slate-500 hover:text-white'} transition-colors`
                }
              >
                Repertoire
              </NavLink>
            </nav>
          )}
        </div>

        <div className="flex items-center gap-5 pl-8">
          {newLawsCount > 0 && (
            <span className="hidden xl:inline-flex text-[10px] font-black uppercase tracking-widest text-[#2DD4BF] bg-[#2DD4BF]/10 border border-[#2DD4BF]/20 px-3 py-1.5 rounded-xl">
              New laws detected
            </span>
          )}

          <button
            onClick={handleNotificationsClick}
            className="flex items-center justify-center w-12 h-12 text-slate-400 hover:text-white hover:bg-white/5 rounded-2xl transition-all relative group"
            title={newLawsCount > 0 ? `${newLawsCount} nouvelle(s) loi(s)` : 'Aucune nouvelle loi'}
          >
            <Bell size={22} className="group-hover:rotate-12 transition-transform" />
            <span className="absolute top-2.5 right-2.5 min-w-5 h-5 px-1 rounded-full bg-[#2DD4BF] text-[#010410] text-[10px] font-black flex items-center justify-center border-2 border-[#0B1121] shadow-lg shadow-[#2DD4BF]/40">
              {newLawsCount > 0 ? newLawsCount : ''}
            </span>
          </button>

          <button className="flex items-center justify-center w-12 h-12 text-slate-400 hover:text-white hover:bg-white/5 rounded-2xl transition-all">
            <HelpCircle size={22} />
          </button>

          <div className="w-[1px] h-8 bg-white/10 mx-2" />

          <div className="flex items-center gap-4 group cursor-pointer hover:bg-white/5 p-2 pr-4 rounded-3xl transition-all border border-transparent hover:border-white/5">
            <div className="text-right hidden sm:block">
              <p className="text-sm font-black text-white leading-none">Capitaine Ahmad</p>
              <p className="text-[10px] font-black text-slate-500 uppercase tracking-widest mt-1">Autorite du Port d'Agadir</p>
            </div>
            <div className="w-12 h-12 border border-white/10 rounded-2xl p-0.5 group-hover:scale-105 transition-transform overflow-hidden shadow-2xl relative">
              <div className="absolute inset-0 bg-gradient-to-tr from-[#2DD4BF]/20 to-transparent" />
              <img
                src="https://api.dicebear.com/7.x/avataaars/svg?seed=Ahmad"
                alt="Profile"
                className="w-full h-full object-cover rounded-xl"
              />
            </div>
          </div>
        </div>
      </header>
    </>
  );
}
