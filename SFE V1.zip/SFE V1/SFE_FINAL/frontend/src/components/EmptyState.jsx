import { SearchX } from 'lucide-react';

export default function EmptyState({ onClearFilters }) {
  return (
    <div className="flex flex-col items-center justify-center p-20 text-center space-y-6 animate-fade-in group">
      <div className="w-24 h-24 bg-white/5 rounded-[40px] flex items-center justify-center text-slate-700 group-hover:bg-[#2DD4BF]/10 group-hover:text-[#2DD4BF] transition-all duration-700 group-hover:rotate-12 group-hover:scale-110">
        <SearchX size={48} strokeWidth={1.5} />
      </div>
      <div className="space-y-2">
        <h3 className="text-2xl font-black text-white tracking-tight leading-none">Aucun résultat trouvé</h3>
        <p className="text-slate-500 max-w-xs mx-auto font-medium leading-relaxed">
          Nous n'avons trouvé aucun texte réglementaire correspondant à vos critères de recherche ou filtres.
        </p>
      </div>
      <button 
        onClick={onClearFilters}
        className="px-8 py-3.5 bg-white/5 hover:bg-white/10 text-white rounded-2xl text-[11px] font-black uppercase tracking-widest border border-white/5 transition-all active:scale-95 shadow-xl"
      >
        Réinitialiser les Filtres
      </button>
    </div>
  );
}
