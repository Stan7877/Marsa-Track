const STATUS_CONFIG = {
  APPLIED: { 
    label: 'APPLIQUÉ', 
    cls: 'bg-[#10B981]/10 text-[#10B981] border-[#10B981]/20' 
  },
  NOT_APPLIED: { 
    label: 'NON APPLIQUÉ', 
    cls: 'bg-[#EF4444]/10 text-[#EF4444] border-[#EF4444]/20' 
  },
  IN_PROGRESS: { 
    label: 'EN COURS', 
    cls: 'bg-[#F59E0B]/10 text-[#F59E0B] border-[#F59E0B]/20' 
  },
};

export default function StatusBadge({ status }) {
  const config = STATUS_CONFIG[status] || { 
    label: String(status).replace('_', ' '), 
    cls: 'bg-slate-500/10 text-slate-500 border-slate-500/20' 
  };
  
  return (
    <span className={`px-3 py-1 text-[10px] font-black rounded-full border tracking-widest ${config.cls}`}>
      {config.label}
    </span>
  );
}
