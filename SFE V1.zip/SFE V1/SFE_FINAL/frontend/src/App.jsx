import { BrowserRouter, Routes, Route } from 'react-router-dom';
import { QueryClient, QueryClientProvider } from '@tanstack/react-query';
import Layout from './components/Layout';
import DashboardPage from './pages/DashboardPage';
import ManageLawsPage from './pages/ManageLawsPage';
import AddLawPage from './pages/AddLawPage';
import LawDetailPage from './pages/LawDetailPage';

const queryClient = new QueryClient({
  defaultOptions: {
    queries: {
      retry: 1,
      refetchOnWindowFocus: false,
    },
  },
});

export default function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <BrowserRouter>
        <Routes>
          <Route path="/" element={<Layout />}>
            <Route index element={<DashboardPage />} />
            <Route path="laws" element={<ManageLawsPage />} />
            <Route path="laws/new" element={<AddLawPage />} />
            <Route path="laws/:id" element={<LawDetailPage />} />
            <Route path="laws/:id/edit" element={<AddLawPage />} />
          </Route>
        </Routes>
      </BrowserRouter>
    </QueryClientProvider>
  );
}
