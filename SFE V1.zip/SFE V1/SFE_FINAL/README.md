# MarsaTrack Agadir — Legal Compliance Platform

Suivi de conformité légale pour Marsa Maroc, Port d'Agadir.

## Stack
- **Backend**: Node.js + Express + Prisma + SQLite
- **Frontend**: React + Vite + TailwindCSS + React Query

## Setup rapide

### 1. Backend
```bash
cd backend
npm install
npx prisma generate
npm run dev
# Server: http://localhost:3001
```

### 2. Frontend
```bash
cd frontend
npm install
npm run dev
# App: http://localhost:5173
```

> La base de données `prisma/dev.db` est déjà fournie avec 226 textes réglementaires importés.

## Structure
```
SFE/
├── BD/                          # Fichier Excel source (226 lois)
├── backend/
│   ├── prisma/
│   │   ├── schema.prisma        # Schéma Prisma (modèle Law simple)
│   │   └── dev.db               # SQLite DB (226 lois importées)
│   ├── src/
│   │   ├── controllers/
│   │   │   └── lawController.js # CRUD + importFromPdf
│   │   ├── routes/
│   │   │   └── laws.js          # Routes + multer
│   │   ├── utils/
│   │   │   └── pdfImporter.js   # Détection par mots-clés QSE
│   │   └── index.js             # Entry point Express
│   ├── import-laws.js           # Script réimportation Excel
│   └── package.json
└── frontend/
    └── src/
        ├── pages/
        │   ├── DashboardPage.jsx
        │   ├── ManageLawsPage.jsx   # Import PDF, filtres dynamiques, export CSV
        │   ├── LawDetailPage.jsx    # Modifier statut, éditer, supprimer
        │   └── AddLawPage.jsx       # Créer + modifier
        ├── services/api.js          # Unique couche API
        └── components/

## API Endpoints
| Method | Route | Description |
|--------|-------|-------------|
| GET    | /api/laws | Liste avec filtres (category, type, status) |
| GET    | /api/laws/:id | Détail d'un texte |
| POST   | /api/laws | Créer un texte |
| PUT    | /api/laws/:id | Modifier (dont statut) |
| DELETE | /api/laws/:id | Supprimer |
| POST   | /api/laws/import-pdf | Import PDF → détection QSE |
| GET    | /api/laws/meta/categories | Catégories disponibles |
| GET    | /api/laws/meta/types | Types disponibles |
