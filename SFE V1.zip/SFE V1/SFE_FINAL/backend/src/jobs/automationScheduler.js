'use strict';

const { runBulletinAutomation } = require('../services/automationService');

const SIX_HOURS_MS = 6 * 60 * 60 * 1000;

let intervalHandle = null;
let running = false;

async function executeJob(trigger = 'schedule') {
  if (running) {
    return { skipped: true, reason: 'job_already_running', trigger };
  }

  running = true;

  try {
    const result = await runBulletinAutomation({ force: false });
    console.log(`[AUTOMATION] ${trigger} run complete`, {
      inserted: result.inserted,
      skipped: result.skipped,
      rejected: result.rejected,
      status: result.status,
    });
    return result;
  } catch (error) {
    console.error('[AUTOMATION] run failed', { trigger, error: error.message });
    return { skipped: true, reason: error.message, trigger };
  } finally {
    running = false;
  }
}

function startBulletinAutomationJob() {
  if (process.env.DISABLE_AUTOMATION_JOB === 'true') {
    console.log('[AUTOMATION] disabled by DISABLE_AUTOMATION_JOB=true');
    return;
  }

  if (intervalHandle) {
    return;
  }

  console.log('[AUTOMATION] starting 6h scheduler');

  setTimeout(() => {
    executeJob('startup').catch(() => undefined);
  }, 10_000);

  intervalHandle = setInterval(() => {
    executeJob('interval').catch(() => undefined);
  }, SIX_HOURS_MS);
}

module.exports = {
  startBulletinAutomationJob,
  executeJob,
};
