'use strict';

const { PrismaClient } = require('@prisma/client');
const { parsePdf } = require('../utils/pdfImporter');
const { analyzeLaw } = require('./aiComplianceService');
const { evaluateLawRelevance } = require('./relevanceEngine');

const prisma = new PrismaClient();

const TOKEN_MIN_LENGTH = 5;
const MIN_COMMON_TOKENS = 2;

function stripAccents(value) {
  return String(value || '')
    .normalize('NFD')
    .replace(/[\u0300-\u036f]/g, '');
}

function normalizeSpaces(text) {
  return String(text || '').replace(/\s+/g, ' ').trim();
}

function normalizeTitleForMatch(title) {
  return stripAccents(String(title || ''))
    .toLowerCase()
    .replace(/\b(arrete|arretes|decret|decrets|dahir|dahirs)\b/g, ' ')
    .replace(/\bn\s*[°º]\s*/g, ' ')
    .replace(/\bno\s+/g, ' ')
    .replace(/\bn[oº°]\s+/g, ' ')
    .replace(/\bnumero\b/g, ' ')
    .replace(/[^a-z0-9\s]/g, ' ')
    .replace(/\b\d+\b/g, ' ')
    .replace(/\s+/g, ' ')
    .trim();
}

function tokenize(text) {
  return normalizeTitleForMatch(text)
    .split(' ')
    .map((token) => token.trim())
    .filter((token) => token.length >= TOKEN_MIN_LENGTH);
}

function uniqueTokens(tokens) {
  return [...new Set(tokens)];
}

function countCommonTokens(candidateTokens, dbTokens) {
  if (!candidateTokens.length || !dbTokens.length) return 0;

  const dbTokenSet = new Set(dbTokens);
  let common = 0;
  for (const token of uniqueTokens(candidateTokens)) {
    if (dbTokenSet.has(token)) common += 1;
  }

  return common;
}

function normalizeImpact(impact) {
  if (Array.isArray(impact)) {
    return impact
      .map((item) => String(item || '').trim())
      .filter(Boolean)
      .join(', ');
  }

  return String(impact || 'Compliance').trim() || 'Compliance';
}

function normalizePriority(priority) {
  const upper = String(priority || '').toUpperCase();
  if (['HIGH', 'MEDIUM', 'LOW'].includes(upper)) return upper;
  return 'MEDIUM';
}

function buildCandidateRows(entries) {
  return (entries || [])
    .map((entry) => {
      const title = normalizeSpaces(entry?.title || '');
      const tokens = tokenize(title);
      return {
        title,
        normalizedTitle: normalizeTitleForMatch(title),
        tokens,
      };
    })
    .filter((entry) => entry.title.length >= 8 && entry.normalizedTitle.length >= 8 && entry.tokens.length > 0);
}

function findBestMatch(candidate, dbRows) {
  let best = null;

  for (const row of dbRows) {
    const commonTokens = countCommonTokens(candidate.tokens, row.tokens);
    if (!best || commonTokens > best.commonTokens) {
      best = {
        law: row,
        commonTokens,
      };
    }
  }

  if (!best || best.commonTokens < MIN_COMMON_TOKENS) {
    return null;
  }

  return best;
}

async function enrichAndPersist(matchRow) {
  const ai = await analyzeLaw(matchRow.law.title);
  const impact = normalizeImpact(ai.impact);
  const priority = normalizePriority(ai.priority);
  const reason = normalizeSpaces(ai.reason);

  await prisma.law.update({
    where: { id: matchRow.law.id },
    data: {
      isApplicable: true,
      reason,
      impact,
      priority,
    },
  });

  return {
    id: matchRow.law.id,
    title: matchRow.law.title,
    priority,
    impact,
    reason,
    commonTokens: matchRow.commonTokens,
  };
}

async function processLawEntries(entries, _context = {}) {
  const candidates = buildCandidateRows(entries);

  if (!candidates.length) {
    return {
      inserted: 0,
      skipped: 0,
      rejected: 0,
      detected: 0,
      matched: 0,
      unmatched: 0,
      extractedCount: 0,
      matchedCount: 0,
      rejectedByDomain: 0,
      results: [],
    };
  }

  const dbRowsRaw = await prisma.law.findMany({
    select: {
      id: true,
      title: true,
      type: true,
      category: true,
      subCategory: true,
      publishedAt: true,
    },
  });

  const dbRows = dbRowsRaw
    .map((row) => ({
      ...row,
      normalizedTitle: normalizeTitleForMatch(row.title),
      tokens: tokenize(row.title),
    }))
    .filter((row) => row.normalizedTitle.length >= 8 && row.tokens.length > 0);

  const bestByLawId = new Map();

  for (const candidate of candidates) {
    const best = findBestMatch(candidate, dbRows);
    if (!best) continue;

    const existing = bestByLawId.get(best.law.id);
    if (!existing || best.commonTokens > existing.commonTokens) {
      bestByLawId.set(best.law.id, {
        ...best,
        extractedTitle: candidate.title,
      });
    }
  }

  const matchedRows = [...bestByLawId.values()].sort((a, b) => b.commonTokens - a.commonTokens);
  const domainValidatedRows = [];
  let rejectedByDomain = 0;

  for (const matchRow of matchedRows) {
    const relevance = evaluateLawRelevance(matchRow.extractedTitle || matchRow.law.title);
    if (relevance.isRelevant !== true) {
      rejectedByDomain += 1;
      continue;
    }

    domainValidatedRows.push(matchRow);
  }

  const results = [];

  for (const matchRow of domainValidatedRows) {
    const enriched = await enrichAndPersist(matchRow);
    results.push(enriched);
  }

  const detected = candidates.length;
  const matched = matchedRows.length;
  const unmatched = Math.max(0, detected - matched);

  return {
    inserted: domainValidatedRows.length,
    skipped: unmatched,
    rejected: rejectedByDomain,
    detected,
    matched,
    unmatched,
    extractedCount: detected,
    matchedCount: matched,
    rejectedByDomain,
    results,
  };
}

async function processPdfBuffer(buffer, context = {}) {
  const parsed = await parsePdf(buffer);
  const processing = await processLawEntries(parsed.entries, context);

  return {
    ...processing,
    method: parsed.method,
    stats: parsed.stats,
  };
}

module.exports = {
  processLawEntries,
  processPdfBuffer,
};
