'use strict';

const { PrismaClient } = require('@prisma/client');

const prisma = new PrismaClient();

async function getStateValue(key, fallback = null) {
  const row = await prisma.ingestionState.findUnique({ where: { key } });
  return row ? row.value : fallback;
}

async function setStateValue(key, value) {
  const normalizedValue = value === null || value === undefined ? null : String(value);

  await prisma.ingestionState.upsert({
    where: { key },
    update: { value: normalizedValue },
    create: { key, value: normalizedValue },
  });
}

module.exports = {
  getStateValue,
  setStateValue,
};
