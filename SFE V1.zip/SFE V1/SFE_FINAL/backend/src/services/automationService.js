'use strict';

const { PrismaClient } = require('@prisma/client');
const { fetchLatestBulletinPdf, downloadPdfBuffer } = require('./bulletinScraper');
const { processPdfBuffer } = require('./lawPipelineService');
const { getStateValue, setStateValue } = require('./ingestionStateService');

const prisma = new PrismaClient();

const STATE_KEYS = {
  LAST_PROCESSED_PDF_URL: 'automation:last_processed_pdf_url',
  LAST_RUN_AT: 'automation:last_run_at',
  LAST_RESULT: 'automation:last_result',
  LAST_SEEN_AT: 'notifications:last_seen_at',
};

async function runBulletinAutomation(options = {}) {
  const force = Boolean(options.force);
  const startedAt = new Date();

  await setStateValue(STATE_KEYS.LAST_RUN_AT, startedAt.toISOString());

  const latest = await fetchLatestBulletinPdf();
  const lastProcessedPdfUrl = await getStateValue(STATE_KEYS.LAST_PROCESSED_PDF_URL, null);

  if (!force && lastProcessedPdfUrl && lastProcessedPdfUrl === latest.pdfUrl) {
    const result = {
      inserted: 0,
      skipped: 0,
      rejected: 0,
      detected: 0,
      status: 'no_new_bulletin',
      bulletinRef: latest.bulletinRef,
      pdfUrl: latest.pdfUrl,
      sourceUrl: latest.sourceUrl,
      ranAt: startedAt.toISOString(),
    };

    await setStateValue(STATE_KEYS.LAST_RESULT, JSON.stringify(result));
    return result;
  }

  const pdfBuffer = await downloadPdfBuffer(latest.pdfUrl);
  const pipelineResult = await processPdfBuffer(pdfBuffer, {
    publishedAt: latest.publishedAt,
    sourceUrl: latest.pdfUrl,
  });

  await setStateValue(STATE_KEYS.LAST_PROCESSED_PDF_URL, latest.pdfUrl);

  const result = {
    ...pipelineResult,
    status: 'processed',
    bulletinRef: latest.bulletinRef,
    pdfUrl: latest.pdfUrl,
    sourceUrl: latest.sourceUrl,
    ranAt: startedAt.toISOString(),
  };

  await setStateValue(STATE_KEYS.LAST_RESULT, JSON.stringify(result));

  return result;
}

async function getAutomationStatus() {
  const [lastRunAt, lastProcessedPdfUrl, lastResultRaw] = await Promise.all([
    getStateValue(STATE_KEYS.LAST_RUN_AT, null),
    getStateValue(STATE_KEYS.LAST_PROCESSED_PDF_URL, null),
    getStateValue(STATE_KEYS.LAST_RESULT, null),
  ]);

  let lastResult = null;
  if (lastResultRaw) {
    try {
      lastResult = JSON.parse(lastResultRaw);
    } catch (_e) {
      lastResult = null;
    }
  }

  return {
    lastRunAt,
    lastProcessedPdfUrl,
    lastResult,
  };
}

async function getNotificationStatus() {
  const lastSeenRaw = await getStateValue(STATE_KEYS.LAST_SEEN_AT, null);
  const lastSeenAt = lastSeenRaw ? new Date(lastSeenRaw) : new Date(0);

  const newLawsCount = await prisma.law.count({
    where: {
      createdAt: {
        gt: lastSeenAt,
      },
    },
  });

  return {
    newLawsCount,
    lastSeenAt: lastSeenAt.toISOString(),
  };
}

async function acknowledgeNotifications() {
  const nowIso = new Date().toISOString();
  await setStateValue(STATE_KEYS.LAST_SEEN_AT, nowIso);
  return { acknowledgedAt: nowIso };
}

module.exports = {
  runBulletinAutomation,
  getAutomationStatus,
  getNotificationStatus,
  acknowledgeNotifications,
};
