'use strict';

const PASS_THRESHOLD = 3;

const DOMAIN_SIGNALS = [
  {
    key: 'maritime_port',
    label: 'Maritime/Port',
    weight: 4,
    patterns: [
      /\bmaritime\b/i,
      /\bport\b/i,
      /\bportuaire\b/i,
      /\bterminal\b/i,
      /\bquai\b/i,
      /\bnavire\b/i,
      /\bnavigation\b/i,
      /\barmateur\b/i,
      /\bpilotage\b/i,
      /\bremorquage\b/i,
      /\bmanutention\b/i,
      /\bescale\b/i,
      /\btransport maritime\b/i,
      /\beaux maritimes\b/i,
      /\bp[êe]che maritime\b/i,
      /\bp[êe]che en mer\b/i,
      /\bfili[èe]re halieutique\b/i,
    ],
  },
  {
    key: 'logistics_trade',
    label: 'Logistics/Import-Export',
    weight: 3,
    patterns: [
      /\blogistique\b/i,
      /\bcargo\b/i,
      /\bcargaison\b/i,
      /\bconteneur\b/i,
      /\bconteneuris[ée]e?\b/i,
      /\bimport\b/i,
      /\bexport\b/i,
      /\bdouane\b/i,
      /\bdouanier\b/i,
      /\bd[ée]douanement\b/i,
      /\btransitaires?\b/i,
      /\btransit\b/i,
      /\bfret\b/i,
      /\bmanifeste\b/i,
    ],
  },
  {
    key: 'environment_safety',
    label: 'Environment/Safety',
    weight: 3,
    patterns: [
      /\benvironnement\b/i,
      /\bpollution\b/i,
      /\brejet\b/i,
      /\bd[ée]chets?\b/i,
      /\bqualit[ée] de l'?eau\b/i,
      /\bprotection marine\b/i,
      /\bs[ée]curit[ée]\b/i,
      /\bs[ûu]ret[ée]\b/i,
      /\baccident\b/i,
      /\brisques? industriels?\b/i,
      /\bincendie\b/i,
      /\bhygi[èe]ne\b/i,
      /\bsant[ée] au travail\b/i,
      /\bplan d'urgence\b/i,
    ],
  },
  {
    key: 'governance_tax',
    label: 'Governance/Tax',
    weight: 2,
    patterns: [
      /\bmarsa maroc\b/i,
      /\bentreprise publique\b/i,
      /\b[ée]tablissement public\b/i,
      /\bconcession\b/i,
      /\bgouvernance\b/i,
      /\bfiscal\b/i,
      /\bimp[oô]t\b/i,
      /\btaxe\b/i,
      /\btva\b/i,
      /\bhydrocarbures?\b/i,
      /\b[ée]nergie\b/i,
    ],
  },
];

const EXCLUSION_RULES = [
  {
    key: 'education',
    patterns: [
      /\b[ée]ducation\b/i,
      /\benseignement\b/i,
      /\buniversit[ée]\b/i,
      /\b[ée]cole\b/i,
    ],
  },
  {
    key: 'healthcare',
    patterns: [
      /\bh[oô]pital\b/i,
      /\bclinique\b/i,
      /\bm[ée]dicament\b/i,
      /\bsant[ée] publique\b/i,
      /\bvaccin\b/i,
    ],
  },
  {
    key: 'macro_finance',
    patterns: [
      /\bbons? du tr[ée]sor\b/i,
      /\bpolitique mon[ée]taire\b/i,
      /\bbanque centrale\b/i,
      /\bdette publique\b/i,
      /\bmarch[ée] financier\b/i,
    ],
  },
  {
    key: 'social_program',
    patterns: [
      /\baide sociale\b/i,
      /\bprogramme social\b/i,
      /\bprotection sociale\b/i,
      /\bprestation sociale\b/i,
    ],
  },
  {
    key: 'agriculture_non_maritime',
    patterns: [
      /\bagriculture\b/i,
      /\bagricole\b/i,
      /\b[ée]levage\b/i,
      /\birrigation\b/i,
      /\bphytosanitaire\b/i,
      /\bengrais\b/i,
    ],
  },
];

const MARITIME_OVERRIDE_PATTERNS = [
  /\bmaritime\b/i,
  /\bport\b/i,
  /\bportuaire\b/i,
  /\bterminal\b/i,
  /\bnavire\b/i,
  /\bp[êe]che\b/i,
  /\beaux maritimes\b/i,
  /\btransport maritime\b/i,
];

const FISHING_CONTEXT_PATTERNS = [/\bp[êe]che\b/i, /\bmaritime\b/i];
const CORE_DOMAIN_SIGNAL_KEYS = new Set(['maritime_port', 'logistics_trade']);

function normalizeText(input) {
  return String(input || '').replace(/\s+/g, ' ').trim();
}

function hasAnyPattern(text, patterns) {
  return patterns.some((pattern) => pattern.test(text));
}

function detectMatchedSignals(title) {
  const matched = [];
  const matchedKeys = [];
  let score = 0;

  for (const signal of DOMAIN_SIGNALS) {
    if (hasAnyPattern(title, signal.patterns)) {
      score += signal.weight;
      matched.push(signal.label);
      matchedKeys.push(signal.key);
    }
  }

  return { score, matchedSignals: matched, matchedSignalKeys: matchedKeys };
}

function detectExclusion(title) {
  for (const rule of EXCLUSION_RULES) {
    if (hasAnyPattern(title, rule.patterns)) {
      return rule.key;
    }
  }
  return null;
}

function hasMaritimeOverride(title) {
  return hasAnyPattern(title, MARITIME_OVERRIDE_PATTERNS);
}

function hasFishingMaritimeContext(title) {
  return FISHING_CONTEXT_PATTERNS.every((pattern) => pattern.test(title));
}

function hasCoreDomainSignal(matchedSignalKeys) {
  return matchedSignalKeys.some((key) => CORE_DOMAIN_SIGNAL_KEYS.has(key));
}

function evaluateLawRelevance(rawTitle) {
  const title = normalizeText(rawTitle);
  if (!title) {
    return {
      passed: false,
      isRelevant: false,
      score: 0,
      threshold: PASS_THRESHOLD,
      matchedSignals: [],
      matchedSignalKeys: [],
      coreDomainSignal: false,
      exclusion: 'empty_title',
      maritimeOverride: false,
      fishingMaritimeContext: false,
      reason: 'No title provided',
    };
  }

  const maritimeOverride = hasMaritimeOverride(title);
  const fishingMaritimeContext = hasFishingMaritimeContext(title);
  const exclusion = detectExclusion(title);

  if (exclusion && !maritimeOverride && !fishingMaritimeContext) {
    return {
      passed: false,
      isRelevant: false,
      score: 0,
      threshold: PASS_THRESHOLD,
      matchedSignals: [],
      matchedSignalKeys: [],
      coreDomainSignal: false,
      exclusion,
      maritimeOverride,
      fishingMaritimeContext,
      reason: `Excluded by rule: ${exclusion}`,
    };
  }

  const { score, matchedSignals, matchedSignalKeys } = detectMatchedSignals(title);
  const passed = score >= PASS_THRESHOLD;
  const coreDomainSignal = hasCoreDomainSignal(matchedSignalKeys);
  const isRelevant = passed && coreDomainSignal;

  return {
    passed,
    isRelevant,
    score,
    threshold: PASS_THRESHOLD,
    matchedSignals,
    matchedSignalKeys,
    coreDomainSignal,
    exclusion,
    maritimeOverride,
    fishingMaritimeContext,
    reason: !passed
      ? `Score below threshold (${score}/${PASS_THRESHOLD})`
      : isRelevant
        ? 'Domain relevance passed'
        : 'Score passed but no core domain signal',
  };
}

function inferCategoryFromSignals(matchedSignals) {
  const joined = matchedSignals.join(' ').toLowerCase();

  if (joined.includes('maritime') || joined.includes('port')) return 'Maritime';
  if (joined.includes('logistics') || joined.includes('import-export')) return 'Autres exigences';
  if (joined.includes('environment') || joined.includes('safety')) return 'Sante & Securite au Travail';
  if (joined.includes('governance') || joined.includes('tax')) return 'Autres exigences';

  return 'Autres exigences';
}

module.exports = {
  PASS_THRESHOLD,
  evaluateLawRelevance,
  inferCategoryFromSignals,
};
