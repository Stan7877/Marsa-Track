'use strict';

const DEFAULT_BULLETIN_SOURCE_URL = 'https://www.sgg.gov.ma/BulletinOfficiel.aspx';

const MONTH_MAP = {
  janvier: 1,
  fevrier: 2,
  'fevrier': 2,
  mars: 3,
  avril: 4,
  mai: 5,
  juin: 6,
  juillet: 7,
  aout: 8,
  'ao�t': 8,
  septembre: 9,
  octobre: 10,
  novembre: 11,
  decembre: 12,
  'd�cembre': 12,
};

function decodeHtmlEntities(input) {
  return String(input || '')
    .replace(/&nbsp;/gi, ' ')
    .replace(/&amp;/gi, '&')
    .replace(/&quot;/gi, '"')
    .replace(/&#39;/gi, "'")
    .replace(/&lt;/gi, '<')
    .replace(/&gt;/gi, '>')
    .replace(/\s+/g, ' ')
    .trim();
}

function toAbsoluteUrl(baseUrl, href) {
  try {
    return new URL(href, baseUrl).toString();
  } catch (_e) {
    return null;
  }
}

function parseDateFromText(text) {
  const normalized = String(text || '').toLowerCase().replace(/\s+/g, ' ').trim();

  const slash = normalized.match(/\b(\d{1,2})[\/\-.](\d{1,2})[\/\-.](\d{4})\b/);
  if (slash) {
    const [, dd, mm, yyyy] = slash;
    const date = new Date(`${yyyy}-${mm.padStart(2, '0')}-${dd.padStart(2, '0')}T00:00:00.000Z`);
    if (!Number.isNaN(date.getTime())) return date;
  }

  const literal = normalized.match(/\b(\d{1,2})\s+([a-z���������������]+)\s+(\d{4})\b/i);
  if (literal) {
    const dd = literal[1];
    const monthName = literal[2];
    const yyyy = literal[3];
    const month = MONTH_MAP[monthName];

    if (month) {
      const date = new Date(`${yyyy}-${String(month).padStart(2, '0')}-${dd.padStart(2, '0')}T00:00:00.000Z`);
      if (!Number.isNaN(date.getTime())) return date;
    }
  }

  return null;
}

function parseBulletinNumber(text) {
  const normalized = String(text || '').toLowerCase();

  const patterns = [
    /bulletin\s*officiel[^\d]{0,10}(\d{3,6})/i,
    /\bbo\s*(\d{3,6})\b/i,
    /\bn\s*[�o�]?\s*(\d{3,6})\b/i,
    /(\d{4,6})/,
  ];

  for (const pattern of patterns) {
    const match = normalized.match(pattern);
    if (match) {
      const value = Number.parseInt(match[1], 10);
      if (Number.isFinite(value)) return value;
    }
  }

  return 0;
}

function scoreCandidate(candidate) {
  const bulletinNumber = candidate.bulletinNumber || 0;
  const dateScore = candidate.publishedAt ? candidate.publishedAt.getTime() / 1_000_000_000 : 0;

  return bulletinNumber * 1000 + dateScore;
}

function extractPdfCandidates(html, sourceUrl) {
  const candidates = [];
  const linkRegex = /<a\s+[^>]*href=["']([^"']+\.pdf(?:\?[^"']*)?)["'][^>]*>([\s\S]*?)<\/a>/gi;

  let match;
  while ((match = linkRegex.exec(html)) !== null) {
    const href = decodeHtmlEntities(match[1]);
    const anchorTextRaw = match[2].replace(/<[^>]+>/g, ' ');
    const anchorText = decodeHtmlEntities(anchorTextRaw);

    const pdfUrl = toAbsoluteUrl(sourceUrl, href);
    if (!pdfUrl) continue;

    const context = `${anchorText} ${href}`;
    const publishedAt = parseDateFromText(context);
    const bulletinNumber = parseBulletinNumber(context);

    candidates.push({
      sourceUrl,
      pdfUrl,
      anchorText,
      bulletinNumber,
      publishedAt,
      score: 0,
    });
  }

  for (const candidate of candidates) {
    candidate.score = scoreCandidate(candidate);
  }

  candidates.sort((a, b) => b.score - a.score);
  return candidates;
}

async function fetchText(url) {
  const controller = new AbortController();
  const timeout = setTimeout(() => controller.abort(), 20000);

  try {
    const response = await fetch(url, {
      method: 'GET',
      signal: controller.signal,
      headers: {
        'User-Agent': 'MarsaTrackComplianceBot/1.0',
        Accept: 'text/html,application/xhtml+xml',
      },
    });

    if (!response.ok) {
      throw new Error(`Source fetch failed (${response.status})`);
    }

    return await response.text();
  } finally {
    clearTimeout(timeout);
  }
}

async function fetchLatestBulletinPdf() {
  const sourceUrl = process.env.BULLETIN_SOURCE_URL || DEFAULT_BULLETIN_SOURCE_URL;
  const html = await fetchText(sourceUrl);
  const candidates = extractPdfCandidates(html, sourceUrl);

  if (!candidates.length) {
    throw new Error('No PDF links detected on Bulletin source page');
  }

  const latest = candidates[0];

  return {
    sourceUrl,
    pdfUrl: latest.pdfUrl,
    bulletinRef: latest.bulletinNumber ? `BO-${latest.bulletinNumber}` : latest.anchorText || 'BO-latest',
    publishedAt: latest.publishedAt,
    debugCandidates: candidates.slice(0, 5),
  };
}

async function downloadPdfBuffer(pdfUrl) {
  const controller = new AbortController();
  const timeout = setTimeout(() => controller.abort(), 25000);

  try {
    const response = await fetch(pdfUrl, {
      method: 'GET',
      signal: controller.signal,
      headers: {
        'User-Agent': 'MarsaTrackComplianceBot/1.0',
        Accept: 'application/pdf,*/*',
      },
    });

    if (!response.ok) {
      throw new Error(`PDF download failed (${response.status})`);
    }

    const arrayBuffer = await response.arrayBuffer();
    return Buffer.from(arrayBuffer);
  } finally {
    clearTimeout(timeout);
  }
}

module.exports = {
  fetchLatestBulletinPdf,
  downloadPdfBuffer,
};
