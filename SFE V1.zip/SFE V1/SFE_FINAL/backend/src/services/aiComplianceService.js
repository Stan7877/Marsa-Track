﻿'use strict';

const { z } = require('zod');

const IMPACT_VALUES = ['Operational', 'Compliance', 'Financial', 'Safety'];

const AI_RESULT_SCHEMA = z.object({
  reason: z.string().min(3),
  impact: z.array(z.enum(IMPACT_VALUES)).min(1),
  priority: z.enum(['HIGH', 'MEDIUM', 'LOW']),
});

function normalizeTitle(title) {
  return String(title || '').replace(/\s+/g, ' ').trim();
}

function extractJson(text) {
  if (!text) return null;

  const cleaned = String(text)
    .replace(/^```json\s*/i, '')
    .replace(/^```\s*/i, '')
    .replace(/```$/i, '')
    .trim();

  try {
    return JSON.parse(cleaned);
  } catch (_e) {
    const start = cleaned.indexOf('{');
    const end = cleaned.lastIndexOf('}');
    if (start !== -1 && end !== -1 && end > start) {
      try {
        return JSON.parse(cleaned.slice(start, end + 1));
      } catch (_e2) {
        return null;
      }
    }
    return null;
  }
}

function fallbackAnalysis(reason) {
  return {
    reason: `Analyse par defaut: ${reason}. Verification manuelle recommandee.`,
    impact: ['Compliance'],
    priority: 'MEDIUM',
  };
}

async function callOpenAI(title) {
  const apiKey = process.env.OPENAI_API_KEY;
  const model = process.env.OPENAI_MODEL || 'gpt-4o-mini';
  const baseUrl = (process.env.OPENAI_BASE_URL || 'https://api.openai.com/v1').replace(/\/$/, '');

  if (!apiKey) {
    throw new Error('OPENAI_API_KEY is not configured');
  }

  const prompt = `You are a legal expert specialized in port operations (Marsa Maroc).\n\nAnalyze this law:\n\n${title}\n\nReturn JSON:\n{\n"reason": "...",\n"impact": ["Operational","Compliance","Financial","Safety"],\n"priority": "HIGH|MEDIUM|LOW"\n}\n\nBe precise and concise.`;

  const controller = new AbortController();
  const timeout = setTimeout(() => controller.abort(), 25000);

  try {
    const response = await fetch(`${baseUrl}/chat/completions`, {
      method: 'POST',
      signal: controller.signal,
      headers: {
        'Content-Type': 'application/json',
        Authorization: `Bearer ${apiKey}`,
      },
      body: JSON.stringify({
        model,
        temperature: 0.2,
        response_format: { type: 'json_object' },
        messages: [
          {
            role: 'system',
            content:
              'You are a legal expert for port operations and compliance. Return valid JSON only.',
          },
          {
            role: 'user',
            content: prompt,
          },
        ],
      }),
    });

    if (!response.ok) {
      const body = await response.text();
      throw new Error(`AI API error ${response.status}: ${body.slice(0, 400)}`);
    }

    const payload = await response.json();
    const content = payload?.choices?.[0]?.message?.content;
    const parsed = extractJson(content);

    if (!parsed) {
      throw new Error('AI returned non-JSON content');
    }

    return AI_RESULT_SCHEMA.parse(parsed);
  } finally {
    clearTimeout(timeout);
  }
}

async function analyzeLaw(rawTitle) {
  const title = normalizeTitle(rawTitle);
  if (!title) {
    return fallbackAnalysis('Titre vide');
  }

  try {
    return await callOpenAI(title);
  } catch (error) {
    return fallbackAnalysis(error.message);
  }
}

module.exports = {
  analyzeLaw,
};
