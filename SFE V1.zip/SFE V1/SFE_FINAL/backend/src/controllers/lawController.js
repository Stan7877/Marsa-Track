'use strict';

const { PrismaClient } = require('@prisma/client');
const { z } = require('zod');
const { processPdfBuffer } = require('../services/lawPipelineService');
const {
  runBulletinAutomation,
  getAutomationStatus,
  getNotificationStatus,
  acknowledgeNotifications,
} = require('../services/automationService');

const prisma = new PrismaClient();

function toDate(value) {
  if (value === null || value === undefined || value === '') return null;
  const parsed = new Date(value);
  return Number.isNaN(parsed.getTime()) ? null : parsed;
}

function toOptionalConfidence(value) {
  if (value === null || value === undefined || value === '') return null;
  const num = Number(value);
  if (!Number.isFinite(num)) return null;
  if (num < 0) return 0;
  if (num > 1) return 1;
  return num;
}

const lawSchema = z.object({
  title: z.string().min(3, 'Le titre doit comporter au moins 3 caracteres'),
  type: z.string().min(2).optional().default('Autre'),
  publishedAt: z.union([z.string(), z.number(), z.date()]).optional().nullable().transform(toDate),
  category: z.string().min(2, 'La categorie est requise'),
  subCategory: z.string().nullable().optional(),
  content: z.string().nullable().optional(),
  isApplicable: z.boolean().optional().default(true),
  status: z.enum(['APPLIED', 'NOT_APPLIED', 'IN_PROGRESS']).optional().default('NOT_APPLIED'),
  reason: z.string().nullable().optional(),
  impact: z.string().nullable().optional(),
  priority: z.enum(['HIGH', 'MEDIUM', 'LOW']).optional().nullable(),
  confidence: z.union([z.string(), z.number()]).optional().nullable().transform(toOptionalConfidence),
});

exports.getAllLaws = async (req, res) => {
  try {
    const { category, status, type, search } = req.query;
    const where = {};

    if (category) where.category = category;
    if (type) where.type = type;
    if (status) where.status = status;
    if (search) {
      where.OR = [
        { title: { contains: search } },
        { content: { contains: search } },
        { category: { contains: search } },
        { reason: { contains: search } },
        { impact: { contains: search } },
      ];
    }

    const laws = await prisma.law.findMany({
      where,
      orderBy: { createdAt: 'desc' },
    });

    res.json(laws);
  } catch (error) {
    res.status(500).json({ error: 'Impossible de recuperer les textes.', details: error.message });
  }
};

exports.getLawById = async (req, res) => {
  try {
    const law = await prisma.law.findUnique({ where: { id: req.params.id } });
    if (!law) return res.status(404).json({ error: 'Texte introuvable.' });
    res.json(law);
  } catch (error) {
    res.status(500).json({ error: 'Impossible de recuperer ce texte.', details: error.message });
  }
};

exports.createLaw = async (req, res) => {
  try {
    const data = lawSchema.parse(req.body);
    const law = await prisma.law.create({ data });
    res.status(201).json(law);
  } catch (error) {
    if (error instanceof z.ZodError) {
      return res.status(400).json({ error: 'Donnees invalides.', details: error.issues });
    }
    res.status(500).json({ error: 'Impossible de creer ce texte.', details: error.message });
  }
};

exports.updateLaw = async (req, res) => {
  try {
    const data = lawSchema.partial().parse(req.body);
    const law = await prisma.law.update({
      where: { id: req.params.id },
      data,
    });
    res.json(law);
  } catch (error) {
    if (error instanceof z.ZodError) {
      return res.status(400).json({ error: 'Donnees invalides.', details: error.issues });
    }
    if (error.code === 'P2025') {
      return res.status(404).json({ error: 'Texte introuvable.' });
    }
    res.status(500).json({ error: 'Impossible de mettre a jour ce texte.', details: error.message });
  }
};

exports.deleteLaw = async (req, res) => {
  try {
    await prisma.law.delete({ where: { id: req.params.id } });
    res.status(204).send();
  } catch (error) {
    if (error.code === 'P2025') {
      return res.status(404).json({ error: 'Texte introuvable.' });
    }
    res.status(500).json({ error: 'Impossible de supprimer ce texte.', details: error.message });
  }
};

exports.getCategories = async (_req, res) => {
  try {
    const rows = await prisma.law.findMany({
      select: { category: true },
      distinct: ['category'],
      orderBy: { category: 'asc' },
    });
    res.json(rows.map((row) => row.category));
  } catch (error) {
    res.status(500).json({ error: 'Impossible de recuperer les categories.', details: error.message });
  }
};

exports.getTypes = async (_req, res) => {
  try {
    const rows = await prisma.law.findMany({
      select: { type: true },
      distinct: ['type'],
      orderBy: { type: 'asc' },
    });
    res.json(rows.map((row) => row.type));
  } catch (error) {
    res.status(500).json({ error: 'Impossible de recuperer les types.', details: error.message });
  }
};

exports.importFromPdf = async (req, res) => {
  try {
    if (!req.file) {
      return res.status(400).json({ error: 'Aucun fichier PDF fourni.' });
    }

    const result = await processPdfBuffer(req.file.buffer, {
      sourceType: 'manual_upload',
    });

    if (result.stats.pages === 0) {
      return res.status(422).json({
        error: 'Ce PDF ne contient pas de texte extractible.',
      });
    }

    const applicableCount = result.results?.length || 0;
    const payload = {
      message: applicableCount > 0 ? `${applicableCount} texte(s) applicable(s) detecte(s).` : 'Aucun texte applicable détecté',
      inserted: result.inserted,
      skipped: result.skipped,
      rejected: result.rejected,
      detected: result.detected,
      matched: result.matched,
      unmatched: result.unmatched,
      duplicates: result.skipped,
      fileName: req.file.originalname,
      method: result.method,
      stats: result.stats,
      results: result.results || [],
    };

    res.status(applicableCount > 0 ? 201 : 200).json(payload);
  } catch (error) {
    console.error('[PDF IMPORT ERROR]', error);
    res.status(500).json({ error: 'Erreur lors de l importation du PDF.', details: error.message });
  }
};

exports.runAutomation = async (req, res) => {
  try {
    const force = req.body?.force === true;
    const result = await runBulletinAutomation({ force });
    res.json(result);
  } catch (error) {
    res.status(500).json({ error: 'Erreur automation Bulletin Officiel.', details: error.message });
  }
};

exports.getAutomationStatus = async (_req, res) => {
  try {
    const status = await getAutomationStatus();
    res.json(status);
  } catch (error) {
    res.status(500).json({ error: 'Impossible de recuperer le statut automation.', details: error.message });
  }
};

exports.getNotificationStatus = async (_req, res) => {
  try {
    const status = await getNotificationStatus();
    res.json(status);
  } catch (error) {
    res.status(500).json({ error: 'Impossible de recuperer les notifications.', details: error.message });
  }
};

exports.acknowledgeNotifications = async (_req, res) => {
  try {
    const result = await acknowledgeNotifications();
    res.json(result);
  } catch (error) {
    res.status(500).json({ error: 'Impossible de valider les notifications.', details: error.message });
  }
};
