'use strict';

const express = require('express');
const multer = require('multer');

const router = express.Router();
const ctrl = require('../controllers/lawController');

const upload = multer({
  storage: multer.memoryStorage(),
  limits: { fileSize: 20 * 1024 * 1024 },
  fileFilter: (_req, file, cb) => {
    if (file.mimetype === 'application/pdf') {
      cb(null, true);
      return;
    }

    cb(new Error('Only PDF files are accepted / Seuls les fichiers PDF sont acceptes.'));
  },
});

router.get('/meta/categories', ctrl.getCategories);
router.get('/meta/types', ctrl.getTypes);

router.get('/automation/status', ctrl.getAutomationStatus);
router.post('/automation/run', ctrl.runAutomation);

router.get('/notifications/status', ctrl.getNotificationStatus);
router.post('/notifications/ack', ctrl.acknowledgeNotifications);

router.post('/import-pdf', upload.single('pdf'), ctrl.importFromPdf);

router.get('/', ctrl.getAllLaws);
router.get('/:id', ctrl.getLawById);
router.post('/', ctrl.createLaw);
router.put('/:id', ctrl.updateLaw);
router.delete('/:id', ctrl.deleteLaw);

module.exports = router;
