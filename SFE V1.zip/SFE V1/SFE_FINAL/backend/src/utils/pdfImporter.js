﻿'use strict';

const pdfParse = require('pdf-parse');

const KEYWORD_PATTERNS = [
  {
    type: 'Arrete',
    regex: /a\s*r\s*r\s*e\s*t\s*e/gi,
  },
  {
    type: 'Decret',
    regex: /d\s*e\s*c\s*r\s*e\s*t/gi,
  },
  {
    type: 'Dahir',
    regex: /d\s*a\s*h\s*i\s*r/gi,
  },
];

const MIN_TITLE_LENGTH = 18;
const MAX_CAPTURE_CHARS = 240;

const FRENCH_MONTHS = {
  janvier: 1,
  fevrier: 2,
  'fevrier': 2,
  mars: 3,
  avril: 4,
  mai: 5,
  juin: 6,
  juillet: 7,
  aout: 8,
  'août': 8,
  septembre: 9,
  octobre: 10,
  novembre: 11,
  decembre: 12,
  'décembre': 12,
};

function stripAccents(value) {
  return String(value || '')
    .normalize('NFD')
    .replace(/[\u0300-\u036f]/g, '');
}

function normalizeText(text) {
  return String(text || '')
    .replace(/\u00a0/g, ' ')
    .replace(/[\r\n\t]+/g, ' ')
    .replace(/\s{2,}/g, ' ')
    .trim();
}

function normalizeForScan(text) {
  return normalizeText(stripAccents(text).toLowerCase());
}

function detectType(normalizedTitle) {
  if (/\barrete\b/.test(normalizedTitle)) return 'Arrete';
  if (/\bdecret\b/.test(normalizedTitle)) return 'Decret';
  if (/\bdahir\b/.test(normalizedTitle)) return 'Dahir';
  return 'Autre';
}

function compactKeyword(text) {
  return String(text || '').replace(/\s+/g, '');
}

function splitOnNaturalBoundary(text) {
  const normalized = normalizeText(text);
  if (!normalized) return '';

  const hardStop = normalized.search(/[.;!?](?:\s|$)/);
  if (hardStop >= 80) {
    return normalized.slice(0, hardStop + 1);
  }

  const articleStop = normalized.search(/\barticle\s+\d+\b/);
  if (articleStop >= 70) {
    return normalized.slice(0, articleStop);
  }

  return normalized;
}

function parseDateFromTitle(title) {
  const normalized = normalizeText(title).toLowerCase();

  const slash = normalized.match(/\b(\d{1,2})\/(\d{1,2})\/(\d{4})\b/);
  if (slash) {
    const date = new Date(`${slash[3]}-${slash[2].padStart(2, '0')}-${slash[1].padStart(2, '0')}T00:00:00.000Z`);
    if (!Number.isNaN(date.getTime())) return date;
  }

  const literal = normalized.match(/\b(\d{1,2})\s+([a-zàâäéèêëîïôöùûüç]+)\s+(\d{4})\b/);
  if (literal) {
    const day = literal[1];
    const month = FRENCH_MONTHS[literal[2]];
    const year = literal[3];

    if (month) {
      const date = new Date(`${year}-${String(month).padStart(2, '0')}-${day.padStart(2, '0')}T00:00:00.000Z`);
      if (!Number.isNaN(date.getTime())) return date;
    }
  }

  return null;
}

function cleanTitle(rawTitle) {
  return normalizeText(rawTitle)
    .replace(/^[-,:;.)\s]+/g, '')
    .replace(/[.\s]+$/g, '')
    .replace(/\bpage\s+\d+\b/g, '')
    .replace(/\s{2,}/g, ' ')
    .trim()
    .slice(0, 400);
}

function extractCandidateBlocks(fullTextNormalized) {
  const entries = [];
  const seen = new Set();

  for (const pattern of KEYWORD_PATTERNS) {
    pattern.regex.lastIndex = 0;
    let match;

    while ((match = pattern.regex.exec(fullTextNormalized)) !== null) {
      const start = match.index;
      const chunk = fullTextNormalized.slice(start, start + MAX_CAPTURE_CHARS);
      if (!chunk) continue;

      const sliced = splitOnNaturalBoundary(chunk);
      const cleaned = cleanTitle(sliced);
      if (cleaned.length < MIN_TITLE_LENGTH) continue;

      const key = compactKeyword(cleaned);
      if (seen.has(key)) continue;

      seen.add(key);
      entries.push({
        title: cleaned,
        type: pattern.type,
        publishedAt: parseDateFromTitle(cleaned),
        pageHint: null,
      });
    }
  }

  if (entries.length >= 8) {
    return entries;
  }

  const fallbackChunks = fullTextNormalized
    .split(/\b(?=arrete|decret|dahir)\b/g)
    .slice(0, 400)
    .map((chunk) => cleanTitle(chunk.slice(0, MAX_CAPTURE_CHARS)))
    .filter((chunk) => chunk.length >= MIN_TITLE_LENGTH);

  for (const chunk of fallbackChunks) {
    const key = compactKeyword(chunk);
    if (seen.has(key)) continue;

    seen.add(key);
    entries.push({
      title: chunk,
      type: detectType(chunk),
      publishedAt: parseDateFromTitle(chunk),
      pageHint: null,
    });
  }

  return entries;
}

async function parsePdf(buffer) {
  const parsed = await pdfParse(buffer);
  const rawText = String(parsed?.text || '');
  const normalizedFullText = normalizeForScan(rawText);

  if (!normalizedFullText) {
    return {
      entries: [],
      stats: { pages: parsed?.numpages || 0, extractedCandidates: 0 },
      method: 'full_text_relaxed',
    };
  }

  const entries = extractCandidateBlocks(normalizedFullText);

  return {
    entries,
    stats: {
      pages: parsed?.numpages || 0,
      extractedCandidates: entries.length,
    },
    method: 'full_text_relaxed',
  };
}

module.exports = {
  parsePdf,
  detectType,
};
