'use strict';
/**
 * import-laws.js
 * One-time script: re-imports all laws from the Excel spreadsheet.
 * Run from backend/ directory: node import-laws.js
 */

const { PrismaClient } = require('@prisma/client');
const xlsx  = require('xlsx');
const path  = require('path');

const prisma = new PrismaClient();
const EXCEL  = path.join(__dirname, '..', 'BD', 'Liste des textes applicables.xlsx');

const CAT_MAP = {
  'E':    'Environnement',
  'SS':   'Sécurité',
  'SST':  'Santé & Sécurité au Travail',
  'SST ': 'Santé & Sécurité au Travail',
  'Q':    'Qualité',
};

function normalizeType(t) {
  if (!t) return 'Autre';
  const s = String(t).trim().toLowerCase();
  if (s.includes('loi'))       return 'Loi';
  if (s.includes('décret') || s.includes('decret')) return 'Décret';
  if (s.includes('arrêté') || s.includes('arrete')) return 'Arrêté';
  if (s.includes('dahir'))     return 'Dahir';
  if (s.includes('circulaire')) return 'Circulaire';
  if (s.includes('règlement') || s.includes('reglement')) return 'Règlement';
  return String(t).trim().slice(0, 60);
}

function parseDate(raw, year) {
  if (raw instanceof Date && !isNaN(raw)) return raw;
  if (typeof raw === 'string' && raw.trim()) {
    const parts = raw.split('/');
    if (parts.length === 3) {
      const d = new Date(`${parts[2]}-${parts[1].padStart(2,'0')}-${parts[0].padStart(2,'0')}T00:00:00.000Z`);
      if (!isNaN(d)) return d;
    }
  }
  if (year && !isNaN(parseInt(year))) return new Date(parseInt(year), 0, 1);
  return null;
}

async function main() {
  console.log('🚀 Importing from:', EXCEL);
  const wb   = xlsx.readFile(EXCEL, { cellDates: true });
  const ws   = wb.Sheets[wb.SheetNames[0]];
  const rows = xlsx.utils.sheet_to_json(ws, { header: 1 }).slice(17);
  console.log(`Found ${rows.length} rows`);

  let inserted = 0, skipped = 0;

  for (const row of rows) {
    const [year, rawDate, type, cat, subCat, title] = row;
    const cleanTitle = title ? String(title).trim() : null;
    if (!cleanTitle) continue;

    const exists = await prisma.law.findFirst({ where: { title: cleanTitle } });
    if (exists) { skipped++; continue; }

    await prisma.law.create({
      data: {
        title:       cleanTitle,
        type:        normalizeType(type),
        publishedAt: parseDate(rawDate, year),
        category:    CAT_MAP[String(cat || '').trim()] || String(cat || 'Autre').trim(),
        subCategory: subCat ? String(subCat).trim() : null,
        isApplicable: true,
        status:      'NOT_APPLIED',
      },
    });
    inserted++;
    if (inserted % 20 === 0) process.stdout.write('.');
  }

  console.log(`\n✅ Inserted: ${inserted} | Skipped: ${skipped}`);
  await prisma.$disconnect();
}

main().catch((e) => { console.error(e); process.exit(1); });
